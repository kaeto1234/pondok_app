@extends('layouts.admin')
@section('title', 'Artikel & Berita')
@section('content')

    <div class="flex justify-between items-center mb-6">
        <h1 class="text-2xl font-bold text-gray-800">Artikel & Berita</h1>
        <a href="{{ route('admin.posts.create', ['type' => 'post']) }}"
            class="bg-[#1e3a5f] text-white px-4 py-2 rounded-lg hover:bg-[#2a4a7a] transition">
            <i class="fas fa-plus mr-2"></i> Tambah Artikel
        </a>
    </div>

    @if (session('success'))
        <div class="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded mb-4">{{ session('success') }}
        </div>
    @endif

    {{-- Search & Filter --}}
    <div class="mb-6 flex gap-3 flex-wrap">
        <div class="flex-1 min-w-48">
            <x-search-bar placeholder="Cari judul artikel..." />
        </div>
        <select onchange="window.location.href=updateQueryParam('category_id', this.value)"
            class="border rounded-lg px-3 py-2 text-sm">
            <option value="">Semua Kategori</option>
            @foreach ($categories as $cat)
                <option value="{{ $cat->id }}" {{ request('category_id') == $cat->id ? 'selected' : '' }}>
                    {{ $cat->name }}
                </option>
            @endforeach
        </select>
        <select onchange="window.location.href=updateQueryParam('status', this.value)"
            class="border rounded-lg px-3 py-2 text-sm">
            <option value="">Semua Status</option>
            <option value="published" {{ request('status') == 'published' ? 'selected' : '' }}>Published</option>
            <option value="draft" {{ request('status') == 'draft' ? 'selected' : '' }}>Draft</option>
        </select>
    </div>

    <div class="bg-white rounded-xl shadow-md overflow-hidden">
        <table class="w-full">
            <thead class="bg-gray-50 border-b">
                <tr>
                    <th class="px-6 py-3 text-left text-sm font-semibold text-gray-600">Judul</th>
                    <th class="px-6 py-3 text-left text-sm font-semibold text-gray-600">Kategori</th>
                    <th class="px-6 py-3 text-left text-sm font-semibold text-gray-600">Status</th>
                    <th class="px-6 py-3 text-left text-sm font-semibold text-gray-600">Tanggal</th>
                    <th class="px-6 py-3 text-left text-sm font-semibold text-gray-600">Aksi</th>
                </tr>
            </thead>
            <tbody>
                @forelse($posts as $post)
                    <tr class="border-b hover:bg-gray-50">
                        <td class="px-6 py-3 font-medium text-sm">{{ $post->title }}</td>
                        <td class="px-6 py-3 text-sm text-gray-500">{{ $post->category->name ?? '-' }}</td>
                        <td class="px-6 py-3">
                            @if ($post->published_at)
                                <span
                                    class="text-xs bg-green-100 text-green-700 px-2 py-1 rounded-full font-semibold">Published</span>
                            @else
                                <span
                                    class="text-xs bg-yellow-100 text-yellow-700 px-2 py-1 rounded-full font-semibold">Draft</span>
                            @endif
                        </td>
                        <td class="px-6 py-3 text-sm text-gray-500">
                            {{ $post->published_at ? $post->published_at->format('d M Y') : '-' }}
                        </td>
                        <td class="px-6 py-3">
                            <div class="flex gap-2">
                                <a href="{{ route('admin.posts.edit', $post->id) }}"
                                    class="text-yellow-600 hover:text-yellow-800 text-sm">
                                    <i class="fas fa-edit mr-1"></i> Edit
                                </a>
                                <form action="{{ route('admin.posts.destroy', $post->id) }}" method="POST" class="inline">
                                    @csrf @method('DELETE')
                                    <button type="submit" class="text-red-600 hover:text-red-800 text-sm"
                                        onclick="return confirm('Yakin hapus artikel ini?')">
                                        <i class="fas fa-trash mr-1"></i> Hapus
                                    </button>
                                </form>
                            </div>
                        </td>
                    </tr>
                @empty
                    <tr>
                        <td colspan="5" class="px-6 py-8 text-center text-gray-500">Belum ada artikel.</td>
                    </tr>
                @endforelse
            </tbody>
        </table>
        @if ($posts->hasPages())
            <div class="px-6 py-4 border-t bg-gray-50">{{ $posts->links() }}</div>
        @endif
    </div>

    <script>
        function updateQueryParam(key, value) {
            const url = new URL(window.location.href);
            if (value) url.searchParams.set(key, value);
            else url.searchParams.delete(key);
            url.searchParams.delete('page');
            return url.toString();
        }
    </script>
@endsection
