<?php $__env->startSection('title', 'Manajemen Guru'); ?>
<?php $__env->startSection('content'); ?>

    <div class="mb-6 flex justify-between items-center">
        <h1 class="text-2xl font-bold text-gray-800">Manajemen Guru</h1>
        <a href="<?php echo e(route('admin.guru.create')); ?>"
            class="bg-navy-primary text-white px-4 py-2 rounded-lg hover:bg-navy-hover transition">
            <i class="fas fa-plus mr-2"></i> Tambah Guru
        </a>
    </div>

    <?php if(session('success')): ?>
        <div class="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded mb-4"><?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>
    <?php if(session('error')): ?>
        <div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-4"><?php echo e(session('error')); ?></div>
    <?php endif; ?>

    
    <div class="mb-6 flex gap-3">
        <div class="flex-1">
            <?php if (isset($component)) { $__componentOriginal4c1005aa12a1806956b715b534f8b19a = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal4c1005aa12a1806956b715b534f8b19a = $attributes; } ?>
<?php $component = App\View\Components\SearchBar::resolve(['placeholder' => 'Cari nama, NIP, atau email guru...'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('search-bar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\SearchBar::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal4c1005aa12a1806956b715b534f8b19a)): ?>
<?php $attributes = $__attributesOriginal4c1005aa12a1806956b715b534f8b19a; ?>
<?php unset($__attributesOriginal4c1005aa12a1806956b715b534f8b19a); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4c1005aa12a1806956b715b534f8b19a)): ?>
<?php $component = $__componentOriginal4c1005aa12a1806956b715b534f8b19a; ?>
<?php unset($__componentOriginal4c1005aa12a1806956b715b534f8b19a); ?>
<?php endif; ?>
        </div>
        <select
            onchange="window.location.href='<?php echo e(route('admin.guru.index')); ?>?status='+this.value+'&search=<?php echo e(request('search')); ?>'"
            class="border rounded-lg px-3 py-2 text-sm">
            <option value="">Semua Status</option>
            <option value="1" <?php echo e(request('status') === '1' ? 'selected' : ''); ?>>Aktif</option>
            <option value="0" <?php echo e(request('status') === '0' ? 'selected' : ''); ?>>Nonaktif</option>
        </select>
    </div>

    <div class="bg-white rounded-xl shadow-md overflow-hidden">
        <table class="w-full">
            <thead class="bg-gray-50 border-b">
                <tr>
                    <th class="px-6 py-3 text-left text-sm font-semibold text-gray-600">Nama Lengkap</th>
                    <th class="px-6 py-3 text-left text-sm font-semibold text-gray-600">NIP</th>
                    <th class="px-6 py-3 text-left text-sm font-semibold text-gray-600">Email</th>
                    <th class="px-6 py-3 text-left text-sm font-semibold text-gray-600">Keahlian</th>
                    <th class="px-6 py-3 text-left text-sm font-semibold text-gray-600">Status</th>
                    <th class="px-6 py-3 text-left text-sm font-semibold text-gray-600">Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $gurus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $guru): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr class="border-b hover:bg-gray-50">
                        <td class="px-6 py-4 font-medium"><?php echo e($guru->nama_lengkap); ?></td>
                        <td class="px-6 py-4 text-sm text-gray-500"><?php echo e($guru->nip ?? '-'); ?></td>
                        <td class="px-6 py-4 text-sm text-gray-500"><?php echo e($guru->email); ?></td>
                        <td class="px-6 py-4 text-sm text-gray-500"><?php echo e($guru->keahlian ?? '-'); ?></td>
                        <td class="px-6 py-4">
                            <?php if($guru->is_active): ?>
                                <span
                                    class="px-2 py-1 text-xs font-semibold bg-green-100 text-green-700 rounded-full">Aktif</span>
                            <?php else: ?>
                                <span
                                    class="px-2 py-1 text-xs font-semibold bg-red-100 text-red-700 rounded-full">Nonaktif</span>
                            <?php endif; ?>
                        </td>
                        <td class="px-6 py-4">
                            <div class="flex gap-2">
                                <a href="<?php echo e(route('admin.guru.edit', $guru->id)); ?>"
                                    class="text-yellow-600 hover:text-yellow-800 text-sm">
                                    <i class="fas fa-edit mr-1"></i> Edit
                                </a>
                                <form action="<?php echo e(route('admin.guru.destroy', $guru->id)); ?>" method="POST" class="inline">
                                    <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="text-red-600 hover:text-red-800 text-sm"
                                        onclick="return confirm('Yakin hapus guru ini? Akun login juga akan terhapus.')">
                                        <i class="fas fa-trash mr-1"></i> Hapus
                                    </button>
                                </form>
                            </div>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="6" class="px-6 py-8 text-center text-gray-500">Belum ada data guru.</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
        <?php if($gurus->hasPages()): ?>
            <div class="px-6 py-4 border-t bg-gray-50"><?php echo e($gurus->links()); ?></div>
        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/qiyor/Documents/PBL/project/pesantren_app/resources/views/admin/guru/index.blade.php ENDPATH**/ ?>