<?php $__env->startSection('title', 'Tingkat Diniyah'); ?>
<?php $__env->startSection('content'); ?>

    <div class="mb-6">
        <h1 class="text-2xl font-bold text-gray-800">Tingkat Diniyah</h1>
    </div>

    <?php if(session('success')): ?>
        <div class="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded mb-4"><?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>
    <?php if(session('error')): ?>
        <div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-4"><?php echo e(session('error')); ?></div>
    <?php endif; ?>

    <div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        <div class="bg-white rounded-xl shadow-sm p-6">
            <h2 class="text-lg font-semibold mb-4 border-b pb-2">Tambah Tingkat</h2>
            <form method="POST" action="<?php echo e(route('admin.tingkat-diniyah.store')); ?>">
                <?php echo csrf_field(); ?>
                <div class="mb-3">
                    <label class="block text-sm font-medium text-gray-700 mb-1">Nama Tingkat</label>
                    <input type="text" name="nama_tingkat" value="<?php echo e(old('nama_tingkat')); ?>"
                        class="w-full border rounded-lg px-3 py-2 text-sm" placeholder="Contoh: Ula 1" required>
                    <?php $__errorArgs = ['nama_tingkat'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="text-red-500 text-xs mt-1"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="mb-3">
                    <label class="block text-sm font-medium text-gray-700 mb-1">Urutan</label>
                    <input type="number" name="urutan" value="<?php echo e(old('urutan')); ?>"
                        class="w-full border rounded-lg px-3 py-2 text-sm" placeholder="Otomatis">
                </div>
                <button type="submit"
                    class="w-full bg-navy-primary text-white py-2 rounded-lg hover:bg-navy-hover transition text-sm">
                    <i class="fas fa-plus mr-1"></i> Tambahkan
                </button>
            </form>
        </div>

        
        <div class="lg:col-span-2 bg-white rounded-xl shadow-sm overflow-hidden">
            <table class="w-full">
                <thead class="bg-gray-50 border-b">
                    <tr>
                        <th class="px-6 py-3 text-left text-sm font-semibold text-gray-600">Urutan</th>
                        <th class="px-6 py-3 text-left text-sm font-semibold text-gray-600">Nama Tingkat</th>
                        <th class="px-6 py-3 text-left text-sm font-semibold text-gray-600">Status</th>
                        <th class="px-6 py-3 text-left text-sm font-semibold text-gray-600">Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $tingkatan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr class="border-b hover:bg-gray-50">
                            <td class="px-6 py-3 text-sm text-gray-500"><?php echo e($t->urutan); ?></td>
                            <td class="px-6 py-3 font-medium"><?php echo e($t->nama_tingkat); ?></td>
                            <td class="px-6 py-3">
                                <?php if($t->is_active): ?>
                                    <span class="px-2 py-1 text-xs bg-green-100 text-green-700 rounded-full">Aktif</span>
                                <?php else: ?>
                                    <span class="px-2 py-1 text-xs bg-gray-100 text-gray-500 rounded-full">Nonaktif</span>
                                <?php endif; ?>
                            </td>
                            <td class="px-6 py-3">
                                <div class="flex gap-2" x-data="{ open: false }">
                                    <button @click="open = !open" class="text-yellow-600 hover:text-yellow-800 text-sm">
                                        <i class="fas fa-edit"></i> Edit
                                    </button>
                                    <form action="<?php echo e(route('admin.tingkat-diniyah.destroy', $t->id)); ?>" method="POST"
                                        class="inline">
                                        <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                                        <button type="submit" class="text-red-600 hover:text-red-800 text-sm"
                                            onclick="return confirm('Yakin hapus tingkat ini?')">
                                            <i class="fas fa-trash"></i> Hapus
                                        </button>
                                    </form>
                                    <div x-show="open"
                                        class="absolute mt-8 bg-white border rounded-lg shadow-lg p-4 z-10 w-64">
                                        <form method="POST" action="<?php echo e(route('admin.tingkat-diniyah.update', $t->id)); ?>">
                                            <?php echo csrf_field(); ?> <?php echo method_field('PUT'); ?>
                                            <input type="text" name="nama_tingkat" value="<?php echo e($t->nama_tingkat); ?>"
                                                class="w-full border rounded px-2 py-1 text-sm mb-2">
                                            <input type="number" name="urutan" value="<?php echo e($t->urutan); ?>"
                                                class="w-full border rounded px-2 py-1 text-sm mb-2">
                                            <select name="is_active" class="w-full border rounded px-2 py-1 text-sm mb-2">
                                                <option value="1" <?php echo e($t->is_active ? 'selected' : ''); ?>>Aktif</option>
                                                <option value="0" <?php echo e(!$t->is_active ? 'selected' : ''); ?>>Nonaktif
                                                </option>
                                            </select>
                                            <button type="submit"
                                                class="w-full bg-navy-primary text-white py-1 rounded text-sm">Simpan</button>
                                        </form>
                                    </div>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="4" class="px-6 py-8 text-center text-gray-500">Belum ada data.</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
    <script src="//unpkg.com/alpinejs" defer></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/qiyor/Documents/PBL/project/pesantren_app/resources/views/admin/tingkat-diniyah/index.blade.php ENDPATH**/ ?>