<?php $__env->startSection('title', 'Kelola Profil Pondok'); ?>

<?php $__env->startSection('content'); ?>
    <div class="mb-6 flex justify-between items-center">
        <div>
            <h1 class="text-2xl font-bold text-gray-800">Kelola <?php echo e($title); ?></h1>
            <p class="text-gray-500">Mengelola data <?php echo e($title); ?> pondok pesantren</p>
        </div>
        <a href="<?php echo e(url('/admin/meta/create/' . $group)); ?>"
            class="bg-[#1e3a5f] text-white px-4 py-2 rounded-lg hover:bg-[#2a4a7a] transition">
            <i class="fas fa-plus mr-2"></i> Tambah Data
        </a>
    </div>

    <div class="bg-white rounded-lg shadow overflow-hidden">
        <table class="w-full">
            <thead class="bg-gray-50">
                <tr class="border-b">
                    <th class="px-6 py-3 text-left text-sm font-semibold text-gray-600">Key</th>
                    <th class="px-6 py-3 text-left text-sm font-semibold text-gray-600">Value</th>
                    <th class="px-6 py-3 text-left text-sm font-semibold text-gray-600">Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $metas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $meta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr class="border-b hover:bg-gray-50">
                        <td class="px-6 py-3 text-sm text-gray-700 font-medium">
                            <?php echo e(ucfirst(str_replace('_', ' ', $meta->meta_key))); ?></td>
                        <td class="px-6 py-3 text-sm text-gray-500"><?php echo e(Str::limit($meta->meta_value, 80)); ?></td>
                        <td class="px-6 py-3">
                            <a href="<?php echo e(url('/admin/meta/edit/' . $meta->id)); ?>"
                                class="text-[#1e3a5f] hover:underline text-sm">
                                <i class="fas fa-edit mr-1"></i> Edit
                            </a>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/qiyor/Documents/PBL/project/pesantren_app/resources/views/admin/meta/index.blade.php ENDPATH**/ ?>