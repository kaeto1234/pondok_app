<?php $__env->startSection('title', 'Input Nilai'); ?>
<?php $__env->startSection('content'); ?>

    <div class="mb-6">
        <h1 class="text-2xl font-bold text-gray-800">Input Nilai</h1>
        <p class="text-gray-500 text-sm mt-1">Pilih jadwal, jenis ujian, dan tanggal untuk mulai input nilai</p>
    </div>

    <?php if(session('success')): ?>
        <div class="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded mb-4"><?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>

    
    <div class="bg-white rounded-xl shadow-sm p-6 mb-6 max-w-2xl">
        <h2 class="text-lg font-semibold text-gray-800 mb-4 border-b pb-2">Pilih Jadwal & Ujian</h2>
        <form method="GET" action="<?php echo e(route('guru.nilai.create')); ?>">
            <div class="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1">Jadwal Mengajar</label>
                    <select name="jadwal_id" class="w-full border rounded-lg px-3 py-2 text-sm" required>
                        <option value="">Pilih Jadwal</option>
                        <?php $__currentLoopData = $jadwal; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $j): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($j->id); ?>">
                                <?php echo e($j->hari); ?> - <?php echo e($j->kurikulum->mataPelajaran->nama_mapel); ?>

                                (<?php echo e($j->kurikulum->tingkatDiniyah->nama_tingkat); ?>)
                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1">Jenis Ujian</label>
                    <select name="jenis_ujian_id" class="w-full border rounded-lg px-3 py-2 text-sm" required>
                        <option value="">Pilih Jenis Ujian</option>
                        <?php $__currentLoopData = \App\Models\JenisUjian::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $j): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($j->id); ?>"><?php echo e($j->nama); ?> (Bobot: <?php echo e($j->bobot); ?>%)</option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1">Tanggal Ujian</label>
                    <input type="date" name="tanggal_ujian" value="<?php echo e(today()->format('Y-m-d')); ?>"
                        class="w-full border rounded-lg px-3 py-2 text-sm" required>
                </div>
            </div>
            <button type="submit"
                class="bg-[#1e3a5f] text-white px-6 py-2 rounded-lg hover:bg-[#2a4a7a] transition text-sm">
                <i class="fas fa-arrow-right mr-1"></i> Lanjut Input Nilai
            </button>
        </form>
    </div>

    
    <div class="bg-white rounded-xl shadow-sm p-6 max-w-2xl">
        <h2 class="text-lg font-semibold text-gray-800 mb-4 border-b pb-2">Lihat Rekap Nilai</h2>
        <a href="<?php echo e(route('guru.nilai.rekap')); ?>"
            class="inline-flex items-center bg-gray-100 text-gray-700 px-6 py-2 rounded-lg hover:bg-gray-200 transition text-sm">
            <i class="fas fa-table mr-2"></i> Lihat Rekap Nilai Semua Santri
        </a>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/qiyor/Documents/PBL/project/pesantren_app/resources/views/guru/nilai/index.blade.php ENDPATH**/ ?>