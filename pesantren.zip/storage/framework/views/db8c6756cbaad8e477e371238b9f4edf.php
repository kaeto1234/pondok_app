    <footer class="bg-gray-900 text-white mt-20">
        <div class="container mx-auto px-4 py-12">
            <div class="grid grid-cols-1 md:grid-cols-4 gap-8">
                <div>
                    <div class="flex items-center space-x-2 mb-4">
                        <i class="fas fa-mosque text-2xl text-primaryLight"></i>
                        <span class="font-bold text-xl">Ponpes Roudlotut Tullab</span>
                    </div>
                    <p class="text-gray-400 text-sm">
                        Mencetak generasi yang beriman, berilmu, dan berakhlak mulia.
                    </p>
                </div>
                <div>
                    <h4 class="font-semibold text-lg mb-4">Tautan Cepat</h4>
                    <ul class="space-y-2 text-gray-400 text-sm">
                        <li><a href="<?php echo e(url('/profil')); ?>" class="hover:text-primaryLight transition">Profil</a></li>
                        <li><a href="<?php echo e(url('/akademik')); ?>" class="hover:text-primaryLight transition">Akademik</a></li>
                        <li><a href="<?php echo e(url('/fasilitas')); ?>" class="hover:text-primaryLight transition">Fasilitas</a></li>
                        <li><a href="<?php echo e(url('/berita')); ?>" class="hover:text-primaryLight transition">Berita</a></li>
                        <li><a href="<?php echo e(url('/kontak')); ?>" class="hover:text-primaryLight transition">Kontak</a></li>
                        <li><a href="<?php echo e(url('/ppdb')); ?>" class="hover:text-primaryLight transition">PPDB</a></li>
                    </ul>
                </div>
                <div>
                    <h4 class="font-semibold text-lg mb-4">Kontak</h4>
                    <ul class="space-y-2 text-gray-400 text-sm">
                        <li><i class="fas fa-map-marker-alt w-5 text-primaryLight"></i> Jl. Pesantren No. 1, Bogor</li>
                        <li><i class="fas fa-phone w-5 text-primaryLight"></i> (021) 1234567</li>
                        <li><i class="fab fa-whatsapp w-5 text-primaryLight"></i> 0812-3456-7890</li>
                        <li><i class="fas fa-envelope w-5 text-primaryLight"></i> info@ponpes.sch.id</li>
                    </ul>
                </div>
                <div>
                    <h4 class="font-semibold text-lg mb-4">Media Sosial</h4>
                    <div class="flex space-x-4">
                        <a href="#" class="w-10 h-10 bg-gray-800 rounded-full flex items-center justify-center text-gray-400 hover:bg-primaryLight hover:text-white transition">
                            <i class="fab fa-facebook-f"></i>
                        </a>
                        <a href="#" class="w-10 h-10 bg-gray-800 rounded-full flex items-center justify-center text-gray-400 hover:bg-primaryLight hover:text-white transition">
                            <i class="fab fa-instagram"></i>
                        </a>
                        <a href="#" class="w-10 h-10 bg-gray-800 rounded-full flex items-center justify-center text-gray-400 hover:bg-primaryLight hover:text-white transition">
                            <i class="fab fa-youtube"></i>
                        </a>
                        <a href="#" class="w-10 h-10 bg-gray-800 rounded-full flex items-center justify-center text-gray-400 hover:bg-primaryLight hover:text-white transition">
                            <i class="fab fa-twitter"></i>
                        </a>
                    </div>
                </div>
            </div>
            <div class="border-t border-gray-800 mt-8 pt-6 text-center text-gray-500 text-sm">
                &copy; <?php echo e(date('Y')); ?> Pondok Pesantren Roudlotut Tullab. All rights reserved.
            </div>
        </div>
    </footer>
<?php /**PATH /home/qiyor/Documents/PBL/project/pesantren_app/resources/views/layouts/footer.blade.php ENDPATH**/ ?>