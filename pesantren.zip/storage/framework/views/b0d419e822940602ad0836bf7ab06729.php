<?php $__env->startSection('title', 'Profil Pondok Pesantren'); ?>

<?php $__env->startSection('content'); ?>
<section class="py-5 bg-light">
    <div class="container">
        <!-- Breadcrumb -->
        <nav class="mb-4">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="<?php echo e(url('/')); ?>" class="text-decoration-none text-primary">Beranda</a></li>
                <li class="breadcrumb-item active text-dark">Profil</li>
            </ol>
        </nav>
        
        <div class="row g-4">
            <!-- SIDEBAR KIRI - Menu Profil -->
            <div class="col-lg-4">
                <div class="card border-0 shadow-sm">
                    <div class="card-header bg-primary text-white fw-semibold py-3">
                        <i class="fas fa-info-circle me-2"></i> Menu Profil
                    </div>
                    <div class="list-group list-group-flush">
                        <a href="<?php echo e(url('/profil/sejarah')); ?>" class="list-group-item list-group-item-action d-flex justify-content-between align-items-center py-3">
                            Sejarah
                            <i class="fas fa-chevron-right text-primary"></i>
                        </a>
                        <a href="<?php echo e(url('/profil/visi-misi')); ?>" class="list-group-item list-group-item-action d-flex justify-content-between align-items-center py-3">
                            Visi & Misi
                            <i class="fas fa-chevron-right text-primary"></i>
                        </a>
                        <a href="<?php echo e(url('/profil/struktur')); ?>" class="list-group-item list-group-item-action d-flex justify-content-between align-items-center py-3">
                            Struktur Organisasi
                            <i class="fas fa-chevron-right text-primary"></i>
                        </a>
                        <a href="<?php echo e(url('/profil/sambutan')); ?>" class="list-group-item list-group-item-action d-flex justify-content-between align-items-center py-3">
                            Sambutan Pimpinan
                            <i class="fas fa-chevron-right text-primary"></i>
                        </a>
                    </div>
                </div>
            </div>
            
            <!-- KONTEN KANAN - Preview Profil -->
            <div class="col-lg-8">
                <div class="card border-0 shadow-sm">
                    <div class="card-body p-4">
                        <h2 class="fw-bold text-primary mb-3">Profil Pondok Pesantren</h2>
                        <p class="lead">Selamat datang di profil Pondok Pesantren Roudlotut Tullab.</p>
                        <hr>
                        <p>Pondok Pesantren Roudlotut Tullab adalah lembaga pendidikan Islam yang berfokus pada pengembangan ilmu agama dan umum. Berdiri sejak tahun 1998, pondok ini telah melahirkan ribuan santri yang berkontribusi di masyarakat.</p>
                        <p>Silakan pilih menu di samping untuk mengetahui lebih lanjut tentang profil pondok kami.</p>
                        
                        <div class="row mt-4 g-3">
                            <div class="col-sm-6">
                                <div class="bg-light p-3 rounded text-center">
                                    <i class="fas fa-calendar-alt fa-2x text-primary mb-2"></i>
                                    <h6 class="fw-semibold">Tahun Berdiri</h6>
                                    <p class="mb-0 fw-bold fs-4">1998</p>
                                </div>
                            </div>
                            <div class="col-sm-6">
                                <div class="bg-light p-3 rounded text-center">
                                    <i class="fas fa-users fa-2x text-primary mb-2"></i>
                                    <h6 class="fw-semibold">Total Santri</h6>
                                    <p class="mb-0 fw-bold fs-4">500+</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/qiyor/Documents/PBL/project/pesantren_app/resources/views/profil/index.blade.php ENDPATH**/ ?>