<?php $__env->startSection('title', 'Kurikulum'); ?>
<?php $__env->startSection('content'); ?>

    <div class="mb-6 flex justify-between items-center">
        <h1 class="text-2xl font-bold text-gray-800">Kurikulum</h1>
    </div>

    <?php if(session('success')): ?>
        <div class="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded mb-4"><?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>
    <?php if(session('error')): ?>
        <div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-4"><?php echo e(session('error')); ?></div>
    <?php endif; ?>

    
    <form method="GET" class="mb-6">
        <div class="flex items-center gap-3">
            <label class="text-sm font-medium text-gray-700">Tahun Ajaran:</label>
            <select name="tahun_ajaran_id" onchange="this.form.submit()" class="border rounded-lg px-3 py-2 text-sm">
                <?php $__currentLoopData = $tahunAjaranList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($ta->id); ?>" <?php echo e($selectedTahun == $ta->id ? 'selected' : ''); ?>>
                        <?php echo e($ta->nama_tahun); ?> <?php echo e($ta->is_active ? '(Aktif)' : ''); ?>

                    </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
    </form>

    <div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        <div class="bg-white rounded-xl shadow-sm p-6">
            <h2 class="text-lg font-semibold mb-4 border-b pb-2">Tambah ke Kurikulum</h2>
            <form method="POST" action="<?php echo e(route('admin.kurikulum.store')); ?>">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="tahun_ajaran_id" value="<?php echo e($selectedTahun); ?>">
                <div class="mb-3">
                    <label class="block text-sm font-medium text-gray-700 mb-1">Tingkat</label>
                    <select name="tingkat_diniyah_id" class="w-full border rounded-lg px-3 py-2 text-sm" required>
                        <option value="">Pilih Tingkat</option>
                        <?php $__currentLoopData = $tingkatan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($t->id); ?>"><?php echo e($t->nama_tingkat); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div class="mb-3">
                    <label class="block text-sm font-medium text-gray-700 mb-1">Mata Pelajaran</label>
                    <select name="mata_pelajaran_id" class="w-full border rounded-lg px-3 py-2 text-sm" required>
                        <option value="">Pilih Mapel</option>
                        <?php $__currentLoopData = $mapelList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($m->id); ?>"><?php echo e($m->nama_mapel); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <button type="submit"
                    class="w-full bg-navy-primary text-white py-2 rounded-lg hover:bg-navy-hover transition text-sm">
                    <i class="fas fa-plus mr-1"></i> Tambahkan
                </button>
            </form>
        </div>

        
        <div class="lg:col-span-2 space-y-4">
            <?php $__empty_1 = true; $__currentLoopData = $tingkatan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tingkat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <?php $kurList = $kurikulum->get($tingkat->id, collect()); ?>
                <div class="bg-white rounded-xl shadow-sm overflow-hidden">
                    <div class="bg-[#0f2b4a] text-white px-4 py-3 flex justify-between items-center">
                        <span class="font-semibold"><?php echo e($tingkat->nama_tingkat); ?></span>
                        <span class="text-xs text-white/70"><?php echo e($kurList->count()); ?> mata pelajaran</span>
                    </div>
                    <?php if($kurList->count()): ?>
                        <table class="w-full">
                            <tbody>
                                <?php $__currentLoopData = $kurList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kur): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr class="border-b hover:bg-gray-50">
                                        <td class="px-4 py-2 text-sm"><?php echo e($kur->mataPelajaran->nama_mapel); ?></td>
                                        <td class="px-4 py-2 text-right">
                                            <form action="<?php echo e(route('admin.kurikulum.destroy', $kur->id)); ?>" method="POST"
                                                class="inline">
                                                <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                                                <button type="submit" class="text-red-500 hover:text-red-700 text-xs"
                                                    onclick="return confirm('Hapus mapel ini dari kurikulum?')">
                                                    <i class="fas fa-times"></i> Hapus
                                                </button>
                                            </form>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    <?php else: ?>
                        <p class="text-center text-gray-400 text-sm py-4">Belum ada mapel di tingkat ini.</p>
                    <?php endif; ?>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <p class="text-gray-500">Belum ada tingkat diniyah.</p>
            <?php endif; ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/qiyor/Documents/PBL/project/pesantren_app/resources/views/admin/kurikulum/index.blade.php ENDPATH**/ ?>