<?php $__env->startSection('title', 'Akademik - Pondok Pesantren Roudlotut Tullab'); ?>

<?php $__env->startSection('content'); ?>
<div class="container mx-auto px-4 py-8">
    <div class="max-w-4xl mx-auto">
        <!-- Breadcrumb -->
        <div class="text-sm text-gray-500 mb-6">
            <a href="<?php echo e(url('/')); ?>" class="hover:text-[#166534]">Beranda</a>
            <span class="mx-2">/</span>
            <span class="text-[#166534]">Akademik</span>
        </div>

        <!-- Header -->
        <div class="text-center mb-10">
            <h1 class="text-3xl md:text-4xl font-bold text-gray-800 dark:text-white mb-2">Program Akademik</h1>
            <p class="text-gray-500">Program pendidikan dan kurikulum Pondok Pesantren Roudlotut Tullab</p>
        </div>

        <!-- Menu Pilihan -->
        <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
            <!-- Program Diniyah -->
            <a href="<?php echo e(url('/akademik/program')); ?>" class="block bg-gray-100 dark:bg-gray-800 rounded-xl p-6 text-center hover:shadow-lg transition">
                <div class="w-16 h-16 bg-[#166534]/10 rounded-full flex items-center justify-center mx-auto mb-4">
                    <i class="fas fa-graduation-cap text-2xl text-[#166534]"></i>
                </div>
                <h2 class="text-xl font-bold text-gray-800 dark:text-white mb-2">Program Diniyah</h2>
                <p class="text-gray-500 text-sm">Diniyah Ula, Diniyah Wustha, dan program unggulan lainnya</p>
            </a>

            <!-- Mata Pelajaran -->
            <a href="<?php echo e(url('/akademik/mapel')); ?>" class="block bg-gray-100 dark:bg-gray-800 rounded-xl p-6 text-center hover:shadow-lg transition">
                <div class="w-16 h-16 bg-[#166534]/10 rounded-full flex items-center justify-center mx-auto mb-4">
                    <i class="fas fa-book-open text-2xl text-[#166534]"></i>
                </div>
                <h2 class="text-xl font-bold text-gray-800 dark:text-white mb-2">Mata Pelajaran</h2>
                <p class="text-gray-500 text-sm">Daftar mata pelajaran dan kitab yang dipelajari</p>
            </a>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/qiyor/Documents/PBL/project/pesantren_app/resources/views/akademik/index.blade.php ENDPATH**/ ?>