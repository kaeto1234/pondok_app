<?php $__env->startSection('title', 'Absensi Mengajar'); ?>
<?php $__env->startSection('content'); ?>

    <div class="mb-6">
        <h1 class="text-2xl font-bold text-gray-800">Jadwal Mengajar Saya</h1>
        <p class="text-gray-500 text-sm mt-1">
            <i class="fas fa-calendar-day mr-1"></i>
            Hari ini: <?php echo e(now()->isoFormat('dddd, D MMMM Y')); ?>

        </p>
    </div>

    <?php if(session('success')): ?>
        <div class="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded mb-4"><?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>
    <?php if(session('error')): ?>
        <div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-4"><?php echo e(session('error')); ?></div>
    <?php endif; ?>

    <div class="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
        <?php $__empty_1 = true; $__currentLoopData = $jadwal; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $j): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div
                class="bg-white rounded-xl shadow-sm overflow-hidden border <?php echo e($j->hari == now()->locale('id')->isoFormat('dddd') ? 'border-[#1e3a5f]' : 'border-transparent'); ?>">

                
                <div class="bg-[#0f2b4a] text-white px-4 py-3 flex justify-between items-center">
                    <div>
                        <p class="font-semibold"><?php echo e($j->hari); ?></p>
                        <p class="text-xs text-white/70">
                            <?php echo e(\Carbon\Carbon::parse($j->jam_mulai)->format('H:i')); ?> -
                            <?php echo e(\Carbon\Carbon::parse($j->jam_selesai)->format('H:i')); ?>

                        </p>
                    </div>
                    <?php if($j->hari == now()->locale('id')->isoFormat('dddd')): ?>
                        <span class="text-xs bg-yellow-400 text-gray-800 px-2 py-0.5 rounded-full font-bold">Hari Ini</span>
                    <?php endif; ?>
                </div>

                
                <div class="p-4">
                    <p class="font-semibold text-gray-800"><?php echo e($j->kurikulum->mataPelajaran->nama_mapel); ?></p>
                    <p class="text-sm text-gray-500"><?php echo e($j->kurikulum->tingkatDiniyah->nama_tingkat); ?></p>
                    <p class="text-xs text-gray-400 mt-1">
                        <i class="fas fa-door-open mr-1"></i> <?php echo e($j->ruangan ?? 'Ruangan belum ditentukan'); ?>

                    </p>

                    
                    <div class="mt-3">
                        <?php if(isset($absensiHariIni[$j->id])): ?>
                            <?php $status = $absensiHariIni[$j->id]; ?>
                            <?php if($status == 'hadir'): ?>
                                <span class="px-2 py-1 text-xs bg-green-100 text-green-700 rounded-full font-semibold">
                                    <i class="fas fa-check mr-1"></i> Sudah Absen - Hadir
                                </span>
                            <?php elseif($status == 'sakit'): ?>
                                <span class="px-2 py-1 text-xs bg-blue-100 text-blue-700 rounded-full font-semibold">
                                    <i class="fas fa-procedures mr-1"></i> Sudah Absen - Sakit
                                </span>
                            <?php elseif($status == 'izin'): ?>
                                <span class="px-2 py-1 text-xs bg-yellow-100 text-yellow-700 rounded-full font-semibold">
                                    <i class="fas fa-clipboard mr-1"></i> Sudah Absen - Izin
                                </span>
                            <?php else: ?>
                                <span class="px-2 py-1 text-xs bg-red-100 text-red-700 rounded-full font-semibold">
                                    <i class="fas fa-times mr-1"></i> Sudah Absen - Alpha
                                </span>
                            <?php endif; ?>
                        <?php else: ?>
                            <span class="px-2 py-1 text-xs bg-gray-100 text-gray-500 rounded-full">
                                <i class="fas fa-clock mr-1"></i> Belum Absen Hari Ini
                            </span>
                        <?php endif; ?>
                    </div>
                </div>

                
                <div class="px-4 pb-4 flex gap-2">
                    <?php if(!isset($absensiHariIni[$j->id])): ?>
                        <a href="<?php echo e(route('guru.absensi.create', $j->id)); ?>"
                            class="flex-1 text-center bg-[#1e3a5f] text-white py-2 rounded-lg text-sm hover:bg-[#2a4a7a] transition">
                            <i class="fas fa-clipboard-check mr-1"></i> Isi Absensi
                        </a>
                    <?php endif; ?>
                    <a href="<?php echo e(route('guru.absensi.rekap', ['jadwal_id' => $j->id])); ?>"
                        class="flex-1 text-center bg-gray-100 text-gray-700 py-2 rounded-lg text-sm hover:bg-gray-200 transition">
                        <i class="fas fa-history mr-1"></i> Rekap
                    </a>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <div class="col-span-3 bg-white rounded-xl shadow-sm p-10 text-center">
                <i class="fas fa-calendar-times text-4xl text-gray-300 mb-3"></i>
                <p class="text-gray-500">Belum ada jadwal mengajar yang ditugaskan.</p>
                <p class="text-gray-400 text-sm mt-1">Hubungi admin untuk pengaturan jadwal.</p>
            </div>
        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/qiyor/Documents/PBL/project/pesantren_app/resources/views/guru/absensi/index.blade.php ENDPATH**/ ?>