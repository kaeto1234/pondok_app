<?php $__env->startSection('title', 'Menu Navigasi'); ?>
<?php $__env->startSection('content'); ?>

    <div class="flex justify-between items-center mb-6">
        <h1 class="text-2xl font-bold text-gray-800">Menu Navigasi</h1>
        <a href="<?php echo e(route('admin.menus.create')); ?>"
            class="bg-[#1e3a5f] text-white px-4 py-2 rounded-lg hover:bg-[#2a4a7a] transition">
            <i class="fas fa-plus mr-2"></i> Tambah Menu
        </a>
    </div>

    <?php if(session('success')): ?>
        <div class="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded mb-4"><?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>

    <div class="bg-white rounded-lg shadow overflow-hidden">
        <table class="w-full">
            <thead class="bg-gray-50">
                <tr class="border-b">
                    <th class="px-6 py-3 text-left text-sm font-semibold text-gray-600">Label</th>
                    <th class="px-6 py-3 text-left text-sm font-semibold text-gray-600">Tipe</th>
                    <th class="px-6 py-3 text-left text-sm font-semibold text-gray-600">URL / Halaman</th>
                    <th class="px-6 py-3 text-left text-sm font-semibold text-gray-600">Urutan</th>
                    <th class="px-6 py-3 text-left text-sm font-semibold text-gray-600">Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $menus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    
                    <tr class="border-b bg-gray-50">
                        <td class="px-6 py-3 font-semibold text-gray-800"><?php echo e($menu->label); ?></td>
                        <td class="px-6 py-3">
                            <?php if($menu->post): ?>
                                <span class="text-xs bg-green-100 text-green-700 px-2 py-1 rounded">Halaman</span>
                            <?php elseif($menu->link): ?>
                                <span class="text-xs bg-blue-100 text-blue-700 px-2 py-1 rounded">Link</span>
                            <?php else: ?>
                                <span class="text-xs bg-gray-100 text-gray-500 px-2 py-1 rounded">Grup</span>
                            <?php endif; ?>
                        </td>
                        <td class="px-6 py-3 text-sm text-gray-600">
                            <?php if($menu->post): ?>
                                <?php echo e($menu->post->post->title ?? '-'); ?>

                            <?php elseif($menu->link): ?>
                                <?php echo e($menu->link->url ?? '-'); ?>

                            <?php else: ?>
                                -
                            <?php endif; ?>
                        </td>
                        <td class="px-6 py-3 text-sm"><?php echo e($menu->order); ?></td>
                        <td class="px-6 py-3">
                            <div class="flex gap-2">
                                <a href="<?php echo e(route('admin.menus.edit', $menu->id)); ?>"
                                    class="text-yellow-600 hover:text-yellow-800 text-sm">
                                    <i class="fas fa-edit mr-1"></i> Edit
                                </a>
                                <form action="<?php echo e(route('admin.menus.destroy', $menu->id)); ?>" method="POST" class="inline">
                                    <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="text-red-600 hover:text-red-800 text-sm"
                                        onclick="return confirm('Hapus menu <?php echo e($menu->label); ?>? Submenu juga akan terhapus.')">
                                        <i class="fas fa-trash mr-1"></i> Hapus
                                    </button>
                                </form>
                            </div>
                        </td>
                    </tr>

                    
                    <?php $__currentLoopData = $menu->children; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $child): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr class="border-b hover:bg-gray-50">
                            <td class="px-6 py-3 text-sm text-gray-600 pl-10">
                                <span class="text-gray-400 mr-1">↳</span> <?php echo e($child->label); ?>

                            </td>
                            <td class="px-6 py-3">
                                <?php if($child->post): ?>
                                    <span class="text-xs bg-green-100 text-green-700 px-2 py-1 rounded">Halaman</span>
                                <?php elseif($child->link): ?>
                                    <span class="text-xs bg-blue-100 text-blue-700 px-2 py-1 rounded">Link</span>
                                <?php else: ?>
                                    <span class="text-xs bg-gray-100 text-gray-500 px-2 py-1 rounded">-</span>
                                <?php endif; ?>
                            </td>
                            <td class="px-6 py-3 text-sm text-gray-600">
                                <?php if($child->post): ?>
                                    <?php echo e($child->post->post->title ?? '-'); ?>

                                <?php elseif($child->link): ?>
                                    <?php echo e($child->link->url ?? '-'); ?>

                                <?php else: ?>
                                    -
                                <?php endif; ?>
                            </td>
                            <td class="px-6 py-3 text-sm"><?php echo e($child->order); ?></td>
                            <td class="px-6 py-3">
                                <div class="flex gap-2">
                                    <a href="<?php echo e(route('admin.menus.edit', $child->id)); ?>"
                                        class="text-yellow-600 hover:text-yellow-800 text-sm">
                                        <i class="fas fa-edit mr-1"></i> Edit
                                    </a>
                                    <form action="<?php echo e(route('admin.menus.destroy', $child->id)); ?>" method="POST"
                                        class="inline">
                                        <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                                        <button type="submit" class="text-red-600 hover:text-red-800 text-sm"
                                            onclick="return confirm('Hapus submenu <?php echo e($child->label); ?>?')">
                                            <i class="fas fa-trash mr-1"></i> Hapus
                                        </button>
                                    </form>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="5" class="px-6 py-8 text-center text-gray-500">Belum ada menu.</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/qiyor/Documents/PBL/project/pesantren_app/resources/views/admin/menus/index.blade.php ENDPATH**/ ?>