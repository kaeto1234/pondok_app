<?php $__env->startSection('title', 'Edit Kitab'); ?>
<?php $__env->startSection('content'); ?>

<div class="mb-6">
    <h1 class="text-2xl font-bold text-gray-800">Edit Kitab</h1>
</div>

<div class="bg-white rounded-xl shadow-sm p-6 max-w-2xl">
    <form method="POST" action="<?php echo e(route('admin.kitab.update', $kitab->id)); ?>">
        <?php echo csrf_field(); ?> <?php echo method_field('PUT'); ?>
        <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div class="md:col-span-2">
                <label class="block text-sm font-medium text-gray-700 mb-1">Nama Kitab <span class="text-red-500">*</span></label>
                <input type="text" name="nama_kitab" value="<?php echo e(old('nama_kitab', $kitab->nama_kitab)); ?>"
                    class="w-full border rounded-lg px-4 py-2 text-sm" required>
                <?php $__errorArgs = ['nama_kitab'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-red-500 text-xs mt-1"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div>
                <label class="block text-sm font-medium text-gray-700 mb-1">Pengarang</label>
                <input type="text" name="pengarang" value="<?php echo e(old('pengarang', $kitab->pengarang)); ?>"
                    class="w-full border rounded-lg px-4 py-2 text-sm">
            </div>
            <div>
                <label class="block text-sm font-medium text-gray-700 mb-1">Penerbit</label>
                <input type="text" name="penerbit" value="<?php echo e(old('penerbit', $kitab->penerbit)); ?>"
                    class="w-full border rounded-lg px-4 py-2 text-sm">
            </div>
            <div>
                <label class="block text-sm font-medium text-gray-700 mb-1">Tahun Terbit</label>
                <input type="number" name="tahun_terbit" value="<?php echo e(old('tahun_terbit', $kitab->tahun_terbit)); ?>"
                    class="w-full border rounded-lg px-4 py-2 text-sm">
            </div>
            <div class="md:col-span-2">
                <label class="block text-sm font-medium text-gray-700 mb-1">Deskripsi</label>
                <textarea name="deskripsi" rows="3"
                    class="w-full border rounded-lg px-4 py-2 text-sm"><?php echo e(old('deskripsi', $kitab->deskripsi)); ?></textarea>
            </div>
            <div class="md:col-span-2">
                <label class="block text-sm font-medium text-gray-700 mb-2">Mata Pelajaran yang Menggunakan Kitab Ini</label>
                <?php $selectedMapel = old('mapel_ids', $kitab->mataPelajaran->pluck('id')->toArray()); ?>
                <div class="grid grid-cols-2 md:grid-cols-3 gap-2">
                    <?php $__currentLoopData = $mapelList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <label class="flex items-center gap-2 text-sm cursor-pointer">
                            <input type="checkbox" name="mapel_ids[]" value="<?php echo e($m->id); ?>"
                                <?php echo e(in_array($m->id, $selectedMapel) ? 'checked' : ''); ?>

                                class="rounded">
                            <?php echo e($m->nama_mapel); ?>

                        </label>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
        <div class="flex gap-3 mt-6">
            <button type="submit" class="bg-navy-primary text-white px-6 py-2 rounded-lg hover:bg-navy-hover transition">
                <i class="fas fa-save mr-1"></i> Update
            </button>
            <a href="<?php echo e(route('admin.kitab.index')); ?>" class="bg-gray-200 text-gray-700 px-6 py-2 rounded-lg hover:bg-gray-300 transition">Batal</a>
        </div>
    </form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/qiyor/Documents/PBL/project/pesantren_app/resources/views/admin/kitab/edit.blade.php ENDPATH**/ ?>