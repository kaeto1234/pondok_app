<?php $__env->startSection('title', 'Daftar Santri'); ?>
<?php $__env->startSection('content'); ?>

    <div class="mb-6">
        <h1 class="text-2xl font-bold text-gray-800">Daftar Santri</h1>
        <p class="text-gray-500 text-sm mt-1">Santri pada tingkat yang Anda ajar</p>
    </div>

    
    <form method="GET" class="mb-6">
        <div class="flex items-center gap-3">
            <label class="text-sm font-medium text-gray-700">Tingkat:</label>
            <select name="tingkat_id" onchange="this.form.submit()" class="border rounded-lg px-3 py-2 text-sm">
                <?php $__currentLoopData = $tingkatList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($t->id); ?>" <?php echo e($selectedTingkat == $t->id ? 'selected' : ''); ?>>
                        <?php echo e($t->nama_tingkat); ?>

                    </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
    </form>

    <div class="bg-white rounded-xl shadow-sm overflow-hidden">
        <table class="w-full">
            <thead class="bg-gray-50 border-b">
                <tr>
                    <th class="px-6 py-3 text-left text-sm font-semibold text-gray-600">Nama Santri</th>
                    <th class="px-6 py-3 text-left text-sm font-semibold text-gray-600">NIS</th>
                    <th class="px-6 py-3 text-left text-sm font-semibold text-gray-600">Jenis Kelamin</th>
                    <th class="px-6 py-3 text-left text-sm font-semibold text-gray-600">Status</th>
                    <th class="px-6 py-3 text-left text-sm font-semibold text-gray-600">Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $santriList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $st): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr class="border-b hover:bg-gray-50">
                        <td class="px-6 py-3 font-medium text-sm"><?php echo e($st->santri->nama_lengkap); ?></td>
                        <td class="px-6 py-3 text-sm text-gray-500"><?php echo e($st->santri->nis); ?></td>
                        <td class="px-6 py-3 text-sm text-gray-500">
                            <?php echo e($st->santri->jenis_kelamin == 'L' ? 'Laki-laki' : 'Perempuan'); ?>

                        </td>
                        <td class="px-6 py-3">
                            <span class="px-2 py-1 text-xs bg-green-100 text-green-700 rounded-full font-semibold">
                                <?php echo e(ucfirst($st->status)); ?>

                            </span>
                        </td>
                        <td class="px-6 py-3">
                            <a href="<?php echo e(route('guru.santri.show', $st->id)); ?>"
                                class="text-blue-600 hover:text-blue-800 text-sm">
                                <i class="fas fa-eye mr-1"></i> Detail
                            </a>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="5" class="px-6 py-8 text-center text-gray-500">
                            Belum ada santri di tingkat ini.
                        </td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/qiyor/Documents/PBL/project/pesantren_app/resources/views/guru/santri/index.blade.php ENDPATH**/ ?>