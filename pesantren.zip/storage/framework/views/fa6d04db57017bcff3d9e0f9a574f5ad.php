<nav class="bg-primary dark:bg-gray-800 shadow-lg sticky top-0 z-50 transition-colors">
        <div class="container mx-auto px-4 md:px-6">
            <div class="flex justify-between items-center py-4">
                <!-- Logo -->
                <div class="flex items-center space-x-2">
                    <i class="fas fa-mosque text-2xl text-white"></i>
                    <span class="text-white font-bold text-xl">Ponpes Roudlotut Tullab</span>
                </div>
                
                <!-- Desktop Menu -->
                <div class="hidden md:flex space-x-6">
                    <a href="<?php echo e(url('/')); ?>" class="text-white/90 hover:text-white hover:bg-primaryLight/20 px-3 py-2 rounded-lg transition">Beranda</a>
                    <a href="<?php echo e(url('/profil')); ?>" class="text-white/90 hover:text-white hover:bg-primaryLight/20 px-3 py-2 rounded-lg transition">Profil</a>
                    <a href="<?php echo e(url('/akademik')); ?>" class="text-white/90 hover:text-white hover:bg-primaryLight/20 px-3 py-2 rounded-lg transition">Akademik</a>
                    <a href="<?php echo e(url('/fasilitas')); ?>" class="text-white/90 hover:text-white hover:bg-primaryLight/20 px-3 py-2 rounded-lg transition">Fasilitas</a>
                    <a href="<?php echo e(url('/berita')); ?>" class="text-white/90 hover:text-white hover:bg-primaryLight/20 px-3 py-2 rounded-lg transition">Berita</a>
                    <a href="<?php echo e(url('/kontak')); ?>" class="text-white/90 hover:text-white hover:bg-primaryLight/20 px-3 py-2 rounded-lg transition">Kontak</a>
                    <a href="<?php echo e(url('/ppdb')); ?>" class="bg-white text-primary px-4 py-2 rounded-lg font-semibold hover:bg-gray-100 transition">PPDB</a>
                </div>
                
                <!-- Dark Mode Toggle + Mobile Menu Button -->
                <div class="flex items-center space-x-3">
                    <button id="darkModeToggle" class="text-white text-xl focus:outline-none">
                        <i id="darkModeIcon" class="fas fa-moon"></i>
                    </button>
                    <button id="mobile-menu-button" class="md:hidden text-white focus:outline-none">
                        <i class="fas fa-bars text-2xl"></i>
                    </button>
                </div>
            </div>
            
            <!-- Mobile Menu -->
            <div id="mobile-menu" class="hidden md:hidden pb-4">
                <a href="<?php echo e(url('/')); ?>" class="block text-white/90 hover:text-white py-2">Beranda</a>
                <a href="<?php echo e(url('/profil')); ?>" class="block text-white/90 hover:text-white py-2">Profil</a>
                <a href="<?php echo e(url('/akademik')); ?>" class="block text-white/90 hover:text-white py-2">Akademik</a>
                <a href="<?php echo e(url('/fasilitas')); ?>" class="block text-white/90 hover:text-white py-2">Fasilitas</a>
                <a href="<?php echo e(url('/berita')); ?>" class="block text-white/90 hover:text-white py-2">Berita</a>
                <a href="<?php echo e(url('/kontak')); ?>" class="block text-white/90 hover:text-white py-2">Kontak</a>
                <a href="<?php echo e(url('/ppdb')); ?>" class="block bg-white text-primary px-4 py-2 rounded-lg font-semibold text-center mt-2">PPDB</a>
            </div>
        </div>
    </nav><?php /**PATH /home/qiyor/Documents/PBL/project/pesantren_app/resources/views/layouts/navbar.blade.php ENDPATH**/ ?>