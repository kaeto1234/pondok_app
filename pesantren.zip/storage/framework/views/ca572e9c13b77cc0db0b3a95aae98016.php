<?php $__env->startSection('title', $post->title); ?>

<?php $__env->startSection('content'); ?>
    <div class="container mx-auto px-4 py-8 animate-fadeIn">
        <div class="max-w-4xl mx-auto">

            <!-- Breadcrumb -->
            <div class="text-sm text-gray-500 mb-6">
                <a href="<?php echo e(url('/')); ?>" class="hover:text-[#166534]">Beranda</a>
                <span class="mx-2">/</span>
                <?php if($post->category): ?>
                    <a href="<?php echo e(url('/kategori/' . $post->category->slug)); ?>"
                        class="hover:text-[#166534]"><?php echo e($post->category->name); ?></a>
                    <span class="mx-2">/</span>
                <?php endif; ?>
                <span class="text-[#166534]"><?php echo e($post->title); ?></span>
            </div>

            <!-- Judul Halaman -->
            <div class="text-center mb-8">
                <h1 class="text-3xl md:text-4xl font-bold text-gray-800 dark:text-white"><?php echo e($post->title); ?></h1>
                <div class="w-24 h-1 bg-primary mx-auto mt-4 rounded-full"></div>
            </div>

            <!-- Featured Image (jika ada) -->
            <?php if($post->featured_image): ?>
                <div class="rounded-2xl overflow-hidden shadow-xl mb-8">
                    <img src="<?php echo e(asset('storage/' . $post->featured_image)); ?>" alt="<?php echo e($post->title); ?>"
                        class="w-full <?php echo e($post->post_type == 'page' ? 'h-auto' : 'h-80 object-cover'); ?>">
                </div>
            <?php endif; ?>

            <!-- Konten -->
            <div class="prose prose-lg max-w-none text-gray-700 dark:text-gray-300 leading-relaxed">
                <?php echo nl2br($post->content); ?>

            </div>

            <!-- Tombol Kembali (khusus post) -->
            <?php if($post->post_type == 'post'): ?>
                <div class="mt-8 text-center">
                    <a href="<?php echo e(url()->previous()); ?>" class="inline-flex items-center gap-2 text-primary hover:underline">
                        <i class="fas fa-arrow-left"></i> Kembali
                    </a>
                </div>
            <?php endif; ?>

        </div>
    </div>

    <style>
        @keyframes fadeIn {
            from {
                opacity: 0;
                transform: translateY(20px);
            }

            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .animate-fadeIn {
            animation: fadeIn 0.6s ease-out;
        }
    </style>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/qiyor/Documents/PBL/project/pesantren_app/resources/views/page.blade.php ENDPATH**/ ?>