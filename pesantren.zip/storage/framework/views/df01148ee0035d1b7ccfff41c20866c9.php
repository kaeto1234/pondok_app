<form method="GET" action="<?php echo e($route ?: request()->url()); ?>" class="flex gap-2 items-center">
    
    <?php $__currentLoopData = request()->except(['search', 'page']); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if(is_array($val)): ?>
            <?php $__currentLoopData = $val; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <input type="hidden" name="<?php echo e($key); ?>[]" value="<?php echo e($v); ?>">
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php else: ?>
            <input type="hidden" name="<?php echo e($key); ?>" value="<?php echo e($val); ?>">
        <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    
    <?php $__currentLoopData = $extras; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <input type="hidden" name="<?php echo e($key); ?>" value="<?php echo e($val); ?>">
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    <div class="relative flex-1">
        <div class="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
            <i class="fas fa-search text-gray-400 text-sm"></i>
        </div>
        <input
            type="text"
            name="search"
            value="<?php echo e(request('search')); ?>"
            placeholder="<?php echo e($placeholder); ?>"
            class="w-full pl-9 pr-4 py-2 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-[#1e3a5f] focus:border-transparent"
            autocomplete="off">
        <?php if(request('search')): ?>
            <a href="<?php echo e(request()->fullUrlWithoutQuery(['search', 'page'])); ?>"
                class="absolute inset-y-0 right-0 pr-3 flex items-center text-gray-400 hover:text-gray-600">
                <i class="fas fa-times text-sm"></i>
            </a>
        <?php endif; ?>
    </div>
    <button type="submit"
        class="bg-[#1e3a5f] text-white px-4 py-2 rounded-lg text-sm hover:bg-[#2a4a7a] transition whitespace-nowrap">
        Cari
    </button>
    <?php if(request('search')): ?>
        <a href="<?php echo e(request()->fullUrlWithoutQuery(['search', 'page'])); ?>"
            class="bg-gray-200 text-gray-700 px-4 py-2 rounded-lg text-sm hover:bg-gray-300 transition whitespace-nowrap">
            Reset
        </a>
    <?php endif; ?>
</form><?php /**PATH /home/qiyor/Documents/PBL/project/pesantren_app/resources/views/components/search-bar.blade.php ENDPATH**/ ?>