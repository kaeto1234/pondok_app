<?php $__env->startSection('title', 'Rekap Nilai'); ?>
<?php $__env->startSection('content'); ?>

    <div class="mb-6 flex items-center gap-3">
        <a href="<?php echo e(route('guru.nilai.index')); ?>" class="text-gray-500 hover:text-[#1e3a5f]">
            <i class="fas fa-arrow-left"></i> Kembali
        </a>
        <h1 class="text-2xl font-bold text-gray-800">Rekap Nilai</h1>
    </div>

    
    <form method="GET" class="mb-6">
        <div class="flex items-center gap-3">
            <label class="text-sm font-medium text-gray-700">Jadwal:</label>
            <select name="jadwal_id" onchange="this.form.submit()" class="border rounded-lg px-3 py-2 text-sm">
                <?php $__currentLoopData = $jadwalList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $j): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($j->id); ?>" <?php echo e($selectedJadwal == $j->id ? 'selected' : ''); ?>>
                        <?php echo e($j->hari); ?> - <?php echo e($j->kurikulum->mataPelajaran->nama_mapel); ?>

                        (<?php echo e($j->kurikulum->tingkatDiniyah->nama_tingkat); ?>)
                    </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
    </form>

    <div class="bg-white rounded-xl shadow-sm overflow-x-auto">
        <table class="w-full">
            <thead class="bg-[#0f2b4a] text-white">
                <tr>
                    <th class="px-4 py-3 text-left text-sm font-semibold sticky left-0 bg-[#0f2b4a]">Nama Santri</th>
                    <th class="px-4 py-3 text-left text-sm font-semibold">NIS</th>
                    <?php $__currentLoopData = $jenisUjianList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ju): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <th class="px-4 py-3 text-center text-sm font-semibold">
                            <?php echo e($ju->nama); ?><br>
                            <span class="text-xs text-white/70">Bobot <?php echo e($ju->bobot); ?>%</span>
                        </th>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <th class="px-4 py-3 text-center text-sm font-semibold">Nilai Akhir</th>
                    <th class="px-4 py-3 text-center text-sm font-semibold">Grade</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $santriList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $st): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <?php
                        $nilaiSantri = $nilaiData->get($st->id, collect());
                        $nilaiAkhir = 0;
                        $totalBobot = 0;

                        foreach ($jenisUjianList as $ju) {
                            $n = $nilaiSantri->where('jenis_ujian_id', $ju->id)->first();
                            if ($n) {
                                $nilaiAkhir += $n->nilai * ($ju->bobot / 100);
                                $totalBobot += $ju->bobot;
                            }
                        }

                        $nilaiAkhir = $totalBobot > 0 ? round($nilaiAkhir, 2) : null;
                    ?>
                    <tr class="border-b hover:bg-gray-50">
                        <td class="px-4 py-3 font-medium text-sm sticky left-0 bg-white"><?php echo e($st->santri->nama_lengkap); ?>

                        </td>
                        <td class="px-4 py-3 text-sm text-gray-500"><?php echo e($st->santri->nis); ?></td>
                        <?php $__currentLoopData = $jenisUjianList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ju): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php $n = $nilaiSantri->where('jenis_ujian_id', $ju->id)->first(); ?>
                            <td class="px-4 py-3 text-center">
                                <?php if($n): ?>
                                    <div class="flex flex-col items-center">
                                        <span class="font-semibold text-sm"><?php echo e($n->nilai); ?></span>
                                        <?php $huruf = \App\Http\Controllers\Guru\NilaiController::konversiHuruf($n->nilai); ?>
                                        <span
                                            class="text-xs px-1.5 py-0.5 rounded
                                <?php echo e($huruf == 'A'
                                    ? 'bg-green-100 text-green-700'
                                    : ($huruf == 'B'
                                        ? 'bg-blue-100 text-blue-700'
                                        : ($huruf == 'C'
                                            ? 'bg-yellow-100 text-yellow-700'
                                            : ($huruf == 'D'
                                                ? 'bg-orange-100 text-orange-700'
                                                : 'bg-red-100 text-red-700')))); ?>">
                                            <?php echo e($huruf); ?>

                                        </span>
                                    </div>
                                <?php else: ?>
                                    <span class="text-gray-300 text-xs">-</span>
                                <?php endif; ?>
                            </td>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <td class="px-4 py-3 text-center font-bold text-sm">
                            <?php echo e($nilaiAkhir ?? '-'); ?>

                        </td>
                        <td class="px-4 py-3 text-center">
                            <?php if($nilaiAkhir !== null): ?>
                                <?php $hurufAkhir = \App\Http\Controllers\Guru\NilaiController::konversiHuruf($nilaiAkhir); ?>
                                <span
                                    class="px-3 py-1 rounded-full font-bold text-sm
                            <?php echo e($hurufAkhir == 'A'
                                ? 'bg-green-100 text-green-700'
                                : ($hurufAkhir == 'B'
                                    ? 'bg-blue-100 text-blue-700'
                                    : ($hurufAkhir == 'C'
                                        ? 'bg-yellow-100 text-yellow-700'
                                        : ($hurufAkhir == 'D'
                                            ? 'bg-orange-100 text-orange-700'
                                            : 'bg-red-100 text-red-700')))); ?>">
                                    <?php echo e($hurufAkhir); ?>

                                </span>
                            <?php else: ?>
                                <span class="text-gray-300 text-xs">-</span>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="<?php echo e(4 + $jenisUjianList->count()); ?>" class="px-6 py-8 text-center text-gray-500">
                            Belum ada data santri.
                        </td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/qiyor/Documents/PBL/project/pesantren_app/resources/views/guru/nilai/rekap.blade.php ENDPATH**/ ?>