<?php $__env->startSection('title', 'Form Pendaftaran - PPDB'); ?>

<?php $__env->startSection('content'); ?>
<div class="container mx-auto px-4 py-8">
    <div class="max-w-3xl mx-auto">
        <div class="text-sm text-gray-500 mb-6">
            <a href="<?php echo e(url('/')); ?>" class="hover:text-[#166534]">Beranda</a>
            <span class="mx-2">/</span>
            <a href="<?php echo e(url('/ppdb')); ?>" class="hover:text-[#166534]">PPDB</a>
            <span class="mx-2">/</span>
            <span class="text-[#166534]">Form Pendaftaran</span>
        </div>

        <div class="bg-white dark:bg-gray-800 rounded-xl shadow-md overflow-hidden">
            <div class="bg-primary px-6 py-4">
                <h1 class="text-2xl font-bold text-white">Formulir Pendaftaran Santri Baru</h1>
                <p class="text-white/80 text-sm">Isi data dengan lengkap dan benar</p>
            </div>

            <form method="POST" action="<?php echo e(route('ppdb.store')); ?>" enctype="multipart/form-data" class="p-6 space-y-6">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="tahun_ajaran_id" value="<?php echo e($tahunAjaranAktif->id ?? ''); ?>">
                
                <?php if(session('error')): ?>
                    <div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded">
                        <?php echo e(session('error')); ?>

                    </div>
                <?php endif; ?>

                <!-- Data Pribadi -->
                <div>
                    <h2 class="text-lg font-semibold text-gray-800 dark:text-white mb-4 border-b pb-2">A. Data Pribadi</h2>
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                            <label class="block text-gray-700 dark:text-gray-300 mb-1">Nama Lengkap <span class="text-red-500">*</span></label>
                            <input type="text" name="nama_lengkap" required class="w-full border border-gray-300 rounded-lg px-4 py-2 focus:ring-2 focus:ring-primary">
                        </div>
                        <div>
                            <label class="block text-gray-700 dark:text-gray-300 mb-1">Tempat Lahir</label>
                            <input type="text" name="tempat_lahir" class="w-full border border-gray-300 rounded-lg px-4 py-2">
                        </div>
                        <div>
                            <label class="block text-gray-700 dark:text-gray-300 mb-1">Tanggal Lahir</label>
                            <input type="date" name="tanggal_lahir" class="w-full border border-gray-300 rounded-lg px-4 py-2">
                        </div>
                        <div>
                            <label class="block text-gray-700 dark:text-gray-300 mb-1">Jenis Kelamin</label>
                            <select name="jenis_kelamin" required class="w-full border border-gray-300 rounded-lg px-4 py-2">
                                <option value="">Pilih</option>
                                <option value="L">Laki-laki</option>
                                <option value="P">Perempuan</option>
                            </select>
                        </div>
                        <div class="md:col-span-2">
                            <label class="block text-gray-700 dark:text-gray-300 mb-1">Alamat</label>
                            <textarea name="alamat" rows="2" class="w-full border border-gray-300 rounded-lg px-4 py-2"></textarea>
                        </div>
                        <div>
                            <label class="block text-gray-700 dark:text-gray-300 mb-1">Asal Sekolah</label>
                            <input type="text" name="asal_sekolah" class="w-full border border-gray-300 rounded-lg px-4 py-2">
                        </div>
                    </div>
                </div>

                <!-- Data Orang Tua -->
                <div>
                    <h2 class="text-lg font-semibold text-gray-800 dark:text-white mb-4 border-b pb-2">B. Data Orang Tua / Wali</h2>
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                            <label class="block text-gray-700 dark:text-gray-300 mb-1">Nama Ayah</label>
                            <input type="text" name="nama_ayah" class="w-full border border-gray-300 rounded-lg px-4 py-2">
                        </div>
                        <div>
                            <label class="block text-gray-700 dark:text-gray-300 mb-1">Pekerjaan Ayah</label>
                            <input type="text" name="pekerjaan_ayah" class="w-full border border-gray-300 rounded-lg px-4 py-2">
                        </div>
                        <div>
                            <label class="block text-gray-700 dark:text-gray-300 mb-1">Nama Ibu</label>
                            <input type="text" name="nama_ibu" class="w-full border border-gray-300 rounded-lg px-4 py-2">
                        </div>
                        <div>
                            <label class="block text-gray-700 dark:text-gray-300 mb-1">Pekerjaan Ibu</label>
                            <input type="text" name="pekerjaan_ibu" class="w-full border border-gray-300 rounded-lg px-4 py-2">
                        </div>
                        <div>
                            <label class="block text-gray-700 dark:text-gray-300 mb-1">No. Telepon Orang Tua</label>
                            <input type="tel" name="telepon_orang_tua" class="w-full border border-gray-300 rounded-lg px-4 py-2">
                        </div>
                        <div>
                            <label class="block text-gray-700 dark:text-gray-300 mb-1">Email (untuk login wali) <span class="text-red-500">*</span></label>
                            <input type="email" name="email" required class="w-full border border-gray-300 rounded-lg px-4 py-2">
                            <p class="text-xs text-gray-400 mt-1">Email ini akan digunakan oleh wali santri untuk login</p>
                        </div>
                    </div>
                </div>

                <!-- Upload Berkas -->
                <div>
                    <h2 class="text-lg font-semibold text-gray-800 dark:text-white mb-4 border-b pb-2">C. Upload Berkas</h2>
                    <div class="space-y-3">
                        <?php if(isset($berkasWajib) && $berkasWajib->count()): ?>
                            <?php $__currentLoopData = $berkasWajib; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $berkas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div>
                                <label class="block text-gray-700 dark:text-gray-300 mb-1">
                                    <?php echo e($berkas->jenisBerkas->nama); ?>

                                    <?php if($berkas->is_wajib): ?>
                                        <span class="text-red-500">*</span>
                                    <?php endif; ?>
                                </label>
                                <input type="file" name="berkas_<?php echo e($berkas->id); ?>" 
                                       class="w-full border border-gray-300 rounded-lg px-4 py-2"
                                       <?php echo e($berkas->is_wajib ? 'required' : ''); ?>>
                                <p class="text-xs text-gray-400 mt-1">
                                    Format: <?php echo e($berkas->jenisBerkas->tipe_file); ?> | 
                                    Maks: <?php echo e(number_format($berkas->jenisBerkas->ukuran_maksimal / 1024, 2)); ?> MB
                                </p>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php else: ?>
                            <p class="text-gray-500">Belum ada konfigurasi berkas untuk periode ini.</p>
                        <?php endif; ?>
                    </div>
                </div>

                <div class="flex gap-3 pt-4">
                    <button type="submit" class="bg-primary text-white px-6 py-2 rounded-lg hover:bg-primaryDark transition">Daftar Sekarang</button>
                    <a href="<?php echo e(url('/ppdb')); ?>" class="bg-gray-200 text-gray-700 px-6 py-2 rounded-lg hover:bg-gray-300 transition">Batal</a>
                </div>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/qiyor/Documents/PBL/project/pesantren_app/resources/views/ppdb/daftar.blade.php ENDPATH**/ ?>