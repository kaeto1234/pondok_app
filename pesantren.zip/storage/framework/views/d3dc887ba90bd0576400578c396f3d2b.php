<?php $__env->startSection('title', 'Dashboard Wali'); ?>

<?php $__env->startSection('content'); ?>
<div class="mb-6">
    <h1 class="text-2xl font-bold text-gray-800">Selamat Datang, <?php echo e(session('user_name')); ?>!</h1>
    <p class="text-gray-500">Pantau perkembangan putra/putri Anda di sini.</p>
</div>

<?php if(session('success')): ?>
    <div class="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded mb-6">
        <?php echo e(session('success')); ?>

    </div>
<?php endif; ?>

<div x-data="{ tab: '<?php echo e(session('tab', 'profile')); ?>' }">
    <div class="flex gap-2 mb-6 border-b">
        <button @click="tab = 'profile'"
            :class="tab === 'profile' ? 'border-b-2 border-[#1e3a5f] text-[#1e3a5f] font-semibold' : 'text-gray-500'"
            class="px-4 py-2 text-sm transition">
            <i class="fas fa-user mr-1"></i> Profil Saya
        </button>
        <button @click="tab = 'santri'"
            :class="tab === 'santri' ? 'border-b-2 border-[#1e3a5f] text-[#1e3a5f] font-semibold' : 'text-gray-500'"
            class="px-4 py-2 text-sm transition">
            <i class="fas fa-child mr-1"></i> Data Santri
        </button>
        <button @click="tab = 'password'"
            :class="tab === 'password' ? 'border-b-2 border-[#1e3a5f] text-[#1e3a5f] font-semibold' : 'text-gray-500'"
            class="px-4 py-2 text-sm transition">
            <i class="fas fa-lock mr-1"></i> Ganti Password
        </button>
    </div>

    
    <div x-show="tab === 'profile'">
        <div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <div class="bg-white rounded-xl shadow-sm p-6 text-center">
                <div class="w-24 h-24 bg-[#1e3a5f] rounded-full flex items-center justify-center mx-auto mb-4">
                    <span class="text-3xl font-bold text-white">
                        <?php echo e(strtoupper(substr(session('user_name'), 0, 1))); ?>

                    </span>
                </div>
                <p class="font-bold text-gray-800"><?php echo e($user->full_name); ?></p>
                <p class="text-sm text-gray-500"><?php echo e($user->email); ?></p>
                <span class="inline-block mt-2 px-3 py-1 text-xs bg-purple-100 text-purple-700 rounded-full font-semibold">Wali Santri</span>
            </div>

            <div class="lg:col-span-2 bg-white rounded-xl shadow-sm p-6">
                <h2 class="text-lg font-semibold text-gray-800 mb-4 border-b pb-2">Edit Profil</h2>
                <form method="POST" action="<?php echo e(route('wali.profile.update')); ?>">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-1">Nama Lengkap</label>
                            <input type="text" name="full_name" value="<?php echo e(old('full_name', $user->full_name)); ?>"
                                class="w-full border rounded-lg px-4 py-2 text-sm" required>
                        </div>
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-1">Username</label>
                            <input type="text" name="username" value="<?php echo e(old('username', $user->username)); ?>"
                                class="w-full border rounded-lg px-4 py-2 text-sm" required>
                        </div>
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-1">Email</label>
                            <input type="email" name="email" value="<?php echo e(old('email', $user->email)); ?>"
                                class="w-full border rounded-lg px-4 py-2 text-sm" required>
                        </div>
                        <?php if($orangTua): ?>
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-1">Telepon Ayah</label>
                            <input type="text" name="telepon_ayah" value="<?php echo e(old('telepon_ayah', $orangTua->telepon_ayah)); ?>"
                                class="w-full border rounded-lg px-4 py-2 text-sm">
                        </div>
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-1">Telepon Ibu</label>
                            <input type="text" name="telepon_ibu" value="<?php echo e(old('telepon_ibu', $orangTua->telepon_ibu)); ?>"
                                class="w-full border rounded-lg px-4 py-2 text-sm">
                        </div>
                        <div class="md:col-span-2">
                            <label class="block text-sm font-medium text-gray-700 mb-1">Alamat</label>
                            <textarea name="alamat" rows="2"
                                class="w-full border rounded-lg px-4 py-2 text-sm"><?php echo e(old('alamat', $orangTua->alamat)); ?></textarea>
                        </div>
                        <?php endif; ?>
                    </div>
                    <?php $__errorArgs = ['full_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-red-500 text-xs mt-2"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-red-500 text-xs mt-2"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    <button type="submit"
                        class="mt-4 bg-[#1e3a5f] text-white px-6 py-2 rounded-lg hover:bg-[#2a4a7a] transition text-sm">
                        <i class="fas fa-save mr-1"></i> Simpan Perubahan
                    </button>
                </form>
            </div>
        </div>
    </div>

    
    <div x-show="tab === 'santri'">
        <div class="bg-white rounded-xl shadow-sm p-6">
            <h2 class="text-lg font-semibold text-gray-800 mb-4 border-b pb-2">Data Santri</h2>
            <?php if($santri): ?>
                <div class="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
                    <div>
                        <p class="text-gray-500">Nama Lengkap</p>
                        <p class="font-semibold"><?php echo e($santri->nama_lengkap); ?></p>
                    </div>
                    <div>
                        <p class="text-gray-500">NIS</p>
                        <p class="font-semibold"><?php echo e($santri->nis); ?></p>
                    </div>
                    <div>
                        <p class="text-gray-500">Tempat, Tanggal Lahir</p>
                        <p class="font-semibold">
                            <?php echo e($santri->tempat_lahir ?? '-'); ?>,
                            <?php echo e($santri->tanggal_lahir ? $santri->tanggal_lahir->format('d M Y') : '-'); ?>

                        </p>
                    </div>
                    <div>
                        <p class="text-gray-500">Jenis Kelamin</p>
                        <p class="font-semibold"><?php echo e($santri->jenis_kelamin == 'L' ? 'Laki-laki' : 'Perempuan'); ?></p>
                    </div>
                    <div>
                        <p class="text-gray-500">Status</p>
                        <span class="px-2 py-1 text-xs font-semibold bg-green-100 text-green-700 rounded-full">
                            <?php echo e(ucfirst($santri->status)); ?>

                        </span>
                    </div>
                    <div>
                        <p class="text-gray-500">Alamat</p>
                        <p class="font-semibold"><?php echo e($santri->alamat ?? '-'); ?></p>
                    </div>
                </div>
            <?php else: ?>
                <p class="text-gray-500 text-sm">Data santri belum tersedia.</p>
            <?php endif; ?>
        </div>
    </div>

    
    <div x-show="tab === 'password'">
        <div class="max-w-lg bg-white rounded-xl shadow-sm p-6">
            <h2 class="text-lg font-semibold text-gray-800 mb-4 border-b pb-2">Ganti Password</h2>
            <form method="POST" action="<?php echo e(route('wali.password.update')); ?>">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>
                <div class="space-y-4">
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-1">Password Lama</label>
                        <input type="password" name="password_lama"
                            class="w-full border rounded-lg px-4 py-2 text-sm" required>
                        <?php $__errorArgs = ['password_lama'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-red-500 text-xs mt-1"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-1">Password Baru</label>
                        <input type="password" name="password_baru"
                            class="w-full border rounded-lg px-4 py-2 text-sm" required>
                    </div>
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-1">Konfirmasi Password Baru</label>
                        <input type="password" name="password_baru_confirmation"
                            class="w-full border rounded-lg px-4 py-2 text-sm" required>
                        <?php $__errorArgs = ['password_baru'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-red-500 text-xs mt-1"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>
                <button type="submit"
                    class="mt-4 bg-[#1e3a5f] text-white px-6 py-2 rounded-lg hover:bg-[#2a4a7a] transition text-sm">
                    <i class="fas fa-key mr-1"></i> Ganti Password
                </button>
            </form>
        </div>
    </div>
</div>

<script src="//unpkg.com/alpinejs" defer></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/qiyor/Documents/PBL/project/pesantren_app/resources/views/wali/dashboard.blade.php ENDPATH**/ ?>