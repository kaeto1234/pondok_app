<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('content'); ?>
<div class="mb-6">
    <h1 class="text-2xl font-bold text-gray-800">Dashboard</h1>
    <p class="text-gray-500">Selamat datang di panel admin Pondok Pesantren Roudlotut Tullab</p>
</div>

<div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
    
    <!-- Total Post -->
    <div class="bg-white rounded-lg shadow p-6">
        <div class="flex items-center justify-between">
            <div>
                <p class="text-gray-500 text-sm">Total Post</p>
                <p class="text-2xl font-bold text-[#1e3a5f]"><?php echo e($totalPosts); ?></p>
            </div>
            <div class="w-12 h-12 bg-[#1e3a5f]/10 rounded-full flex items-center justify-center">
                <i class="fas fa-newspaper text-[#1e3a5f] text-xl"></i>
            </div>
        </div>
    </div>
    
    <!-- Total Kategori -->
    <div class="bg-white rounded-lg shadow p-6">
        <div class="flex items-center justify-between">
            <div>
                <p class="text-gray-500 text-sm">Total Kategori</p>
                <p class="text-2xl font-bold text-[#1e3a5f]"><?php echo e($totalCategories); ?></p>
            </div>
            <div class="w-12 h-12 bg-[#1e3a5f]/10 rounded-full flex items-center justify-center">
                <i class="fas fa-tags text-[#1e3a5f] text-xl"></i>
            </div>
        </div>
    </div>
    
    <!-- Total Menu -->
    <div class="bg-white rounded-lg shadow p-6">
        <div class="flex items-center justify-between">
            <div>
                <p class="text-gray-500 text-sm">Total Menu</p>
                <p class="text-2xl font-bold text-[#1e3a5f]"><?php echo e($totalMenus); ?></p>
            </div>
            <div class="w-12 h-12 bg-[#1e3a5f]/10 rounded-full flex items-center justify-center">
                <i class="fas fa-bars text-[#1e3a5f] text-xl"></i>
            </div>
        </div>
    </div>
    
    <!-- Total Post by Kategori (Ringkasan) -->
    <div class="bg-white rounded-lg shadow p-6">
        <div class="flex items-center justify-between">
            <div>
                <p class="text-gray-500 text-sm">Post per Kategori</p>
                <p class="text-xs text-gray-600">
                    📄 Profil: <?php echo e($totalProfil); ?> |
                    📞 Kontak: <?php echo e($totalKontak); ?> |
                    🎓 Akademik: <?php echo e($totalAkademik); ?> |
                    🏠 Fasilitas: <?php echo e($totalFasilitas); ?>

                </p>
            </div>
            <div class="w-12 h-12 bg-[#1e3a5f]/10 rounded-full flex items-center justify-center">
                <i class="fas fa-chart-simple text-[#1e3a5f] text-xl"></i>
            </div>
        </div>
    </div>
    
</div>

<!-- Info tambahan -->
<div class="grid grid-cols-1 md:grid-cols-2 gap-6 mt-6">
    <div class="bg-white rounded-lg shadow p-6">
        <h3 class="font-semibold text-gray-800 mb-2">📝 Post Terbaru</h3>
        <?php
            $latestPosts = App\Models\Post::orderBy('created_at', 'desc')->limit(5)->get();
        ?>
        <ul class="space-y-2">
            <?php $__currentLoopData = $latestPosts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li class="text-sm text-gray-600">
                <span class="text-xs bg-gray-100 px-2 py-0.5 rounded"><?php echo e($post->post_type); ?></span>
                <?php echo e($post->title); ?>

                <span class="text-xs text-gray-400"><?php echo e($post->created_at->diffForHumans()); ?></span>
            </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
        <?php if($latestPosts->isEmpty()): ?>
        <p class="text-gray-400 text-sm">Belum ada post</p>
        <?php endif; ?>
    </div>
    
    <div class="bg-white rounded-lg shadow p-6">
        <h3 class="font-semibold text-gray-800 mb-2">📌 Menu Navigasi</h3>
        <?php
            $menus = App\Models\Menu::whereNull('parent_id')->orderBy('order')->limit(5)->get();
        ?>
        <ul class="space-y-2">
            <?php $__currentLoopData = $menus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li class="text-sm text-gray-600">
                • <?php echo e($menu->label); ?>

                <?php if($menu->children->count()): ?>
                    <span class="text-xs text-gray-400">(<?php echo e($menu->children->count()); ?> sub menu)</span>
                <?php endif; ?>
            </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
        <?php if($menus->isEmpty()): ?>
        <p class="text-gray-400 text-sm">Belum ada menu</p>
        <?php endif; ?>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/qiyor/Documents/PBL/project/pesantren_app/resources/views/admin/dashboard.blade.php ENDPATH**/ ?>