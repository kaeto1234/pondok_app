<?php $__env->startSection('title', 'Kategori'); ?>

<?php $__env->startSection('content'); ?>
<div class="flex justify-between items-center mb-6">
    <h1 class="text-2xl font-bold text-gray-800">Manajemen Kategori</h1>
    <a href="<?php echo e(route('admin.categories.create')); ?>" class="bg-[#1e3a5f] text-white px-4 py-2 rounded-lg hover:bg-[#2a4a7a] transition">
        <i class="fas fa-plus mr-2"></i> Tambah Kategori
    </a>
</div>

<div class="bg-white rounded-lg shadow overflow-hidden">
    <table class="w-full">
        <thead class="bg-gray-50">
            <tr class="border-b">
                <th class="px-6 py-3 text-left text-sm font-semibold text-gray-600">Nama</th>
                <th class="px-6 py-3 text-left text-sm font-semibold text-gray-600">Slug</th>
                <th class="px-6 py-3 text-left text-sm font-semibold text-gray-600">Deskripsi</th>
                <th class="px-6 py-3 text-left text-sm font-semibold text-gray-600">Aksi</th>
            
        </thead>
        <tbody>
            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr class="border-b hover:bg-gray-50">
                <td class="px-6 py-3"><?php echo e($cat->name); ?></td>
                <td class="px-6 py-3 text-gray-500"><?php echo e($cat->slug); ?></td>
                <td class="px-6 py-3 text-gray-500"><?php echo e(Str::limit($cat->description, 50)); ?></td>
                <td class="px-6 py-3">
                    <a href="<?php echo e(route('admin.categories.edit', $cat->id)); ?>" class="text-blue-600 hover:underline mr-2">Edit</a>
                    <form action="<?php echo e(route('admin.categories.destroy', $cat->id)); ?>" method="POST" class="inline">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button type="submit" class="text-red-600 hover:underline" onclick="return confirm('Yakin?')">Hapus</button>
                    </form>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/qiyor/Documents/PBL/project/pesantren_app/resources/views/admin/categories/index.blade.php ENDPATH**/ ?>