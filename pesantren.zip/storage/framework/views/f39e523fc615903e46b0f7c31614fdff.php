<?php $__env->startSection('title', 'Edit Santri'); ?>
<?php $__env->startSection('content'); ?>

    <div class="mb-6 flex items-center gap-3">
        <a href="<?php echo e(route('admin.santri.show', $santri->id)); ?>" class="text-gray-500 hover:text-[#1e3a5f]">
            <i class="fas fa-arrow-left"></i> Kembali
        </a>
        <h1 class="text-2xl font-bold text-gray-800">Edit Santri</h1>
    </div>

    <div class="bg-white rounded-xl shadow-sm p-6 max-w-2xl">
        <form method="POST" action="<?php echo e(route('admin.santri.update', $santri->id)); ?>">
            <?php echo csrf_field(); ?> <?php echo method_field('PUT'); ?>
            <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1">NIS <span
                            class="text-red-500">*</span></label>
                    <input type="text" name="nis" value="<?php echo e(old('nis', $santri->nis)); ?>"
                        class="w-full border rounded-lg px-4 py-2 text-sm" required>
                    <?php $__errorArgs = ['nis'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="text-red-500 text-xs mt-1"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1">Nama Lengkap <span
                            class="text-red-500">*</span></label>
                    <input type="text" name="nama_lengkap" value="<?php echo e(old('nama_lengkap', $santri->nama_lengkap)); ?>"
                        class="w-full border rounded-lg px-4 py-2 text-sm" required>
                    <?php $__errorArgs = ['nama_lengkap'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="text-red-500 text-xs mt-1"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1">Tempat Lahir</label>
                    <input type="text" name="tempat_lahir" value="<?php echo e(old('tempat_lahir', $santri->tempat_lahir)); ?>"
                        class="w-full border rounded-lg px-4 py-2 text-sm">
                </div>
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1">Tanggal Lahir</label>
                    <input type="date" name="tanggal_lahir"
                        value="<?php echo e(old('tanggal_lahir', $santri->tanggal_lahir?->format('Y-m-d'))); ?>"
                        class="w-full border rounded-lg px-4 py-2 text-sm">
                </div>
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1">Jenis Kelamin</label>
                    <select name="jenis_kelamin" class="w-full border rounded-lg px-4 py-2 text-sm" required>
                        <option value="L" <?php echo e($santri->jenis_kelamin == 'L' ? 'selected' : ''); ?>>Laki-laki</option>
                        <option value="P" <?php echo e($santri->jenis_kelamin == 'P' ? 'selected' : ''); ?>>Perempuan</option>
                    </select>
                </div>
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1">No. Telepon</label>
                    <input type="text" name="telepon" value="<?php echo e(old('telepon', $santri->telepon)); ?>"
                        class="w-full border rounded-lg px-4 py-2 text-sm">
                </div>
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1">Status</label>
                    <select name="status" class="w-full border rounded-lg px-4 py-2 text-sm" required>
                        <option value="aktif" <?php echo e($santri->status == 'aktif' ? 'selected' : ''); ?>>Aktif</option>
                        <option value="lulus" <?php echo e($santri->status == 'lulus' ? 'selected' : ''); ?>>Lulus</option>
                        <option value="keluar" <?php echo e($santri->status == 'keluar' ? 'selected' : ''); ?>>Keluar</option>
                    </select>
                </div>
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1">Tingkat Saat Ini</label>
                    <select name="tingkat_id" class="w-full border rounded-lg px-4 py-2 text-sm">
                        <option value="">Tidak Diubah</option>
                        <?php $__currentLoopData = $tingkatList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php $aktif = $santri->santriTingkat->where('status', 'aktif')->first(); ?>
                            <option value="<?php echo e($t->id); ?>" <?php echo e($aktif?->tingkat_id == $t->id ? 'selected' : ''); ?>>
                                <?php echo e($t->nama_tingkat); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div class="md:col-span-2">
                    <label class="block text-sm font-medium text-gray-700 mb-1">Alamat</label>
                    <textarea name="alamat" rows="2" class="w-full border rounded-lg px-4 py-2 text-sm"><?php echo e(old('alamat', $santri->alamat)); ?></textarea>
                </div>
            </div>
            <div class="flex gap-3 mt-4">
                <button type="submit" class="bg-[#1e3a5f] text-white px-6 py-2 rounded-lg hover:bg-[#2a4a7a] transition">
                    <i class="fas fa-save mr-1"></i> Simpan
                </button>
                <a href="<?php echo e(route('admin.santri.show', $santri->id)); ?>"
                    class="bg-gray-200 text-gray-700 px-6 py-2 rounded-lg hover:bg-gray-300 transition">Batal</a>
            </div>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/qiyor/Documents/PBL/project/pesantren_app/resources/views/admin/santri/edit.blade.php ENDPATH**/ ?>