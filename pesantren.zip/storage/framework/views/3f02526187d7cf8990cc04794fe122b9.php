<?php $__env->startSection('title', 'Manajemen Tahun Ajaran'); ?>

<?php $__env->startSection('content'); ?>
    <div class="mb-6 flex justify-between items-center">
        <div>
            <h1 class="text-2xl font-bold text-gray-800">Manajemen Tahun Ajaran</h1>
            <p class="text-sm text-gray-500 mt-1">
                <i class="fas fa-info-circle mr-1"></i>
                Klik "Aktifkan" untuk mengganti tahun ajaran aktif. Tahun ajaran sebelumnya otomatis dinonaktifkan.
            </p>
        </div>
        <a href="<?php echo e(route('admin.tahun-ajaran.create')); ?>"
            class="bg-navy-primary text-white px-4 py-2 rounded-lg hover:bg-navy-hover transition">
            <i class="fas fa-plus mr-2"></i> Tambah Tahun Ajaran
        </a>
    </div>

    <?php if(session('success')): ?>
        <div class="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded mb-4">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>

    <?php if(session('error')): ?>
        <div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-4">
            <?php echo e(session('error')); ?>

        </div>
    <?php endif; ?>

    <div class="bg-white rounded-xl shadow-md overflow-hidden">
        <table class="w-full">
            <thead class="bg-gray-50 border-b">
                <tr>
                    <th class="px-6 py-3 text-left text-sm font-semibold text-gray-600">Nama Tahun</th>
                    <th class="px-6 py-3 text-left text-sm font-semibold text-gray-600">Tanggal Mulai</th>
                    <th class="px-6 py-3 text-left text-sm font-semibold text-gray-600">Tanggal Selesai</th>
                    <th class="px-6 py-3 text-left text-sm font-semibold text-gray-600">Status</th>
                    <th class="px-6 py-3 text-left text-sm font-semibold text-gray-600">Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $tahunAjaran; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr class="border-b hover:bg-gray-50">
                        <td class="px-6 py-4 font-medium"><?php echo e($ta->nama_tahun); ?></td>
                        <td class="px-6 py-4"><?php echo e($ta->tanggal_mulai ? $ta->tanggal_mulai->format('d M Y') : '-'); ?></td>
                        <td class="px-6 py-4"><?php echo e($ta->tanggal_selesai ? $ta->tanggal_selesai->format('d M Y') : '-'); ?></td>
                        <td class="px-6 py-4">
                            <?php if($ta->is_active): ?>
                                <span
                                    class="px-2 py-1 text-xs font-semibold bg-green-100 text-green-700 rounded-full">Aktif</span>
                            <?php else: ?>
                                <span class="px-2 py-1 text-xs font-semibold bg-gray-100 text-gray-500 rounded-full">Tidak
                                    Aktif</span>
                            <?php endif; ?>
                        </td>
                        <td class="px-6 py-4">
                            <div class="flex gap-2 flex-wrap">
                                <?php if(!$ta->is_active): ?>
                                    <form action="<?php echo e(route('admin.tahun-ajaran.set-active', $ta->id)); ?>" method="POST"
                                        class="inline">
                                        <?php echo csrf_field(); ?>
                                        <button type="submit" class="text-green-600 hover:text-green-800 text-sm"
                                            onclick="return confirm('Aktifkan tahun ajaran <?php echo e($ta->nama_tahun); ?>?')">
                                            <i class="fas fa-check-circle mr-1"></i> Aktifkan
                                        </button>
                                    </form>
                                <?php endif; ?>
                                <a href="<?php echo e(route('admin.berkas-tahun-ajaran.index', $ta->id)); ?>"
                                    class="text-blue-600 hover:text-blue-800 text-sm">
                                    <i class="fas fa-folder-open mr-1"></i> Kelola Berkas
                                </a>
                                <a href="<?php echo e(route('admin.tahun-ajaran.edit', $ta->id)); ?>"
                                    class="text-yellow-600 hover:text-yellow-800 text-sm">
                                    <i class="fas fa-edit mr-1"></i> Edit
                                </a>
                                <?php if(!$ta->is_active): ?>
                                    <form action="<?php echo e(route('admin.tahun-ajaran.destroy', $ta->id)); ?>" method="POST"
                                        class="inline">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="submit" class="text-red-600 hover:text-red-800 text-sm"
                                            onclick="return confirm('Yakin ingin menghapus tahun ajaran <?php echo e($ta->nama_tahun); ?>?')">
                                            <i class="fas fa-trash mr-1"></i> Hapus
                                        </button>
                                    </form>
                                <?php endif; ?>
                            </div>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="5" class="px-6 py-8 text-center text-gray-500">Belum ada data tahun ajaran.</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/qiyor/Documents/PBL/project/pesantren_app/resources/views/admin/tahun-ajaran/index.blade.php ENDPATH**/ ?>