<?php $__env->startSection('title', 'Manajemen PPDB'); ?>

<?php $__env->startSection('content'); ?>
    <div class="mb-6 flex justify-between items-center">
        <h1 class="text-2xl font-bold text-gray-800">Daftar Pendaftar Baru (PPDB)</h1>
    </div>

    <?php if(session('success')): ?>
        <div class="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded mb-4">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>

    
    <div class="mb-6 flex gap-3">
        <div class="flex-1">
            <?php if (isset($component)) { $__componentOriginal4c1005aa12a1806956b715b534f8b19a = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal4c1005aa12a1806956b715b534f8b19a = $attributes; } ?>
<?php $component = App\View\Components\SearchBar::resolve(['placeholder' => 'Cari nama atau no. pendaftaran...'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('search-bar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\SearchBar::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal4c1005aa12a1806956b715b534f8b19a)): ?>
<?php $attributes = $__attributesOriginal4c1005aa12a1806956b715b534f8b19a; ?>
<?php unset($__attributesOriginal4c1005aa12a1806956b715b534f8b19a); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4c1005aa12a1806956b715b534f8b19a)): ?>
<?php $component = $__componentOriginal4c1005aa12a1806956b715b534f8b19a; ?>
<?php unset($__componentOriginal4c1005aa12a1806956b715b534f8b19a); ?>
<?php endif; ?>
        </div>
        <select
            onchange="window.location.href='<?php echo e(route('admin.ppdb.index')); ?>?status='+this.value+'&search=<?php echo e(request('search')); ?>'"
            class="border rounded-lg px-3 py-2 text-sm">
            <option value="">Semua Status</option>
            <option value="pending" <?php echo e(request('status') == 'pending' ? 'selected' : ''); ?>>Pending</option>
            <option value="diverifikasi" <?php echo e(request('status') == 'diverifikasi' ? 'selected' : ''); ?>>Diverifikasi</option>
            <option value="ditolak" <?php echo e(request('status') == 'ditolak' ? 'selected' : ''); ?>>Ditolak</option>
        </select>
    </div>

    <div class="bg-white rounded-xl shadow-md overflow-hidden">
        <div class="overflow-x-auto">
            <table class="w-full text-left border-collapse">
                <thead class="bg-gray-50 border-b">
                    <tr>
                        <th class="px-6 py-4 font-semibold text-gray-700">No. Pendaftaran</th>
                        <th class="px-6 py-4 font-semibold text-gray-700">Nama Lengkap</th>
                        <th class="px-6 py-4 font-semibold text-gray-700">Periode</th>
                        <th class="px-6 py-4 font-semibold text-gray-700">Tanggal Daftar</th>
                        <th class="px-6 py-4 font-semibold text-gray-700">Status</th>
                        <th class="px-6 py-4 font-semibold text-gray-700 text-right">Aksi</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-gray-100">
                    <?php $__empty_1 = true; $__currentLoopData = $pendaftarans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pendaftaran): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr class="hover:bg-gray-50 transition">
                            <td class="px-6 py-4 font-medium text-navy-primary"><?php echo e($pendaftaran->no_pendaftaran); ?></td>
                            <td class="px-6 py-4"><?php echo e($pendaftaran->nama_lengkap); ?></td>
                            <td class="px-6 py-4 text-sm text-gray-500"><?php echo e($pendaftaran->tahunAjaran->nama_tahun ?? '-'); ?>

                            </td>
                            <td class="px-6 py-4 text-sm text-gray-500">
                                <?php echo e($pendaftaran->tanggal_daftar->format('d M Y H:i')); ?></td>
                            <td class="px-6 py-4">
                                <?php if($pendaftaran->status == 'pending'): ?>
                                    <span
                                        class="px-2 py-1 text-xs font-semibold bg-yellow-100 text-yellow-700 rounded-full">Pending</span>
                                <?php elseif($pendaftaran->status == 'diverifikasi'): ?>
                                    <span
                                        class="px-2 py-1 text-xs font-semibold bg-green-100 text-green-700 rounded-full">Diverifikasi</span>
                                <?php else: ?>
                                    <span
                                        class="px-2 py-1 text-xs font-semibold bg-red-100 text-red-700 rounded-full">Ditolak</span>
                                <?php endif; ?>
                            </td>
                            <td class="px-6 py-4 text-right">
                                <a href="<?php echo e(route('admin.ppdb.show', $pendaftaran->id)); ?>"
                                    class="text-navy-primary hover:text-navy-hover font-medium text-sm inline-flex items-center">
                                    <i class="fas fa-eye mr-1"></i> Detail
                                </a>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="6" class="px-6 py-10 text-center text-gray-500">Belum ada data pendaftaran.</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
        <?php if($pendaftarans->hasPages()): ?>
            <div class="px-6 py-4 border-t bg-gray-50">
                <?php echo e($pendaftarans->links()); ?>

            </div>
        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/qiyor/Documents/PBL/project/pesantren_app/resources/views/admin/ppdb/index.blade.php ENDPATH**/ ?>