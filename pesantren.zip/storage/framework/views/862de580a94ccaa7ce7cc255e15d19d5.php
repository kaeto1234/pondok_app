<?php $__env->startSection('title', 'Edit Absensi Santri'); ?>
<?php $__env->startSection('content'); ?>

    <div class="mb-6 flex items-center gap-3">
        <a href="<?php echo e(route('guru.absensi.rekap', ['jadwal_id' => $absensiGuru->jadwal_mengajar_id])); ?>"
            class="text-gray-500 hover:text-[#1e3a5f]">
            <i class="fas fa-arrow-left"></i> Kembali
        </a>
        <div>
            <h1 class="text-2xl font-bold text-gray-800">Edit Absensi Santri</h1>
            <p class="text-gray-500 text-sm">
                <?php echo e($absensiGuru->jadwalMengajar->kurikulum->mataPelajaran->nama_mapel); ?> -
                <?php echo e($absensiGuru->jadwalMengajar->kurikulum->tingkatDiniyah->nama_tingkat); ?> |
                Pertemuan ke-<?php echo e($absensiGuru->pertemuan_ke); ?> |
                <?php echo e($absensiGuru->tanggal->format('d M Y')); ?>

            </p>
        </div>
    </div>

    <?php if(session('success')): ?>
        <div class="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded mb-4"><?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>

    <form method="POST" action="<?php echo e(route('guru.absensi.update-santri', $absensiGuru->id)); ?>">
        <?php echo csrf_field(); ?> <?php echo method_field('PUT'); ?>

        <div class="bg-white rounded-xl shadow-sm p-6 mb-6">
            <div class="flex justify-between items-center mb-4 border-b pb-2">
                <h2 class="text-lg font-semibold text-gray-800">
                    <i class="fas fa-users mr-2 text-[#1e3a5f]"></i>
                    Daftar Absensi Santri
                </h2>
                <div class="flex gap-2">
                    <button type="button" onclick="tandaiSemua('hadir')"
                        class="text-xs bg-green-100 text-green-700 px-3 py-1 rounded-full hover:bg-green-200">
                        Semua Hadir
                    </button>
                    <button type="button" onclick="tandaiSemua('alpha')"
                        class="text-xs bg-red-100 text-red-700 px-3 py-1 rounded-full hover:bg-red-200">
                        Semua Alpha
                    </button>
                </div>
            </div>

            <?php $__empty_1 = true; $__currentLoopData = $absensiGuru->absensiSantri; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $as): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div class="flex flex-col md:flex-row md:items-center gap-3 py-3 border-b last:border-0">
                    <div class="w-8 h-8 bg-[#1e3a5f] rounded-full flex items-center justify-center flex-shrink-0">
                        <span class="text-white text-xs font-bold">
                            <?php echo e(strtoupper(substr($as->santriTingkat->santri->nama_lengkap, 0, 1))); ?>

                        </span>
                    </div>
                    <div class="flex-1">
                        <p class="font-medium text-sm text-gray-800"><?php echo e($as->santriTingkat->santri->nama_lengkap); ?></p>
                        <p class="text-xs text-gray-400">NIS: <?php echo e($as->santriTingkat->santri->nis); ?></p>
                    </div>
                    <div class="flex gap-3 flex-wrap">
                        <?php $__currentLoopData = ['hadir' => 'green', 'sakit' => 'blue', 'izin' => 'yellow', 'alpha' => 'red']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val => $color): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <label class="flex items-center gap-1 text-xs cursor-pointer">
                                <input type="radio" name="absensi[<?php echo e($as->id); ?>][status]"
                                    value="<?php echo e($val); ?>" class="santri-status accent-<?php echo e($color); ?>-600"
                                    <?php echo e($as->status == $val ? 'checked' : ''); ?>>
                                <span
                                    class="text-<?php echo e($color); ?>-700 font-medium capitalize"><?php echo e(ucfirst($val)); ?></span>
                            </label>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <div class="md:w-48">
                        <input type="text" name="absensi[<?php echo e($as->id); ?>][keterangan]"
                            value="<?php echo e($as->keterangan); ?>" class="w-full border rounded px-2 py-1 text-xs text-gray-600"
                            placeholder="Keterangan...">
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <p class="text-center text-gray-400 py-6">Belum ada data absensi santri.</p>
            <?php endif; ?>
        </div>

        
        <?php if($santriTambahan->count() > 0): ?>
            <div class="bg-white rounded-xl shadow-sm p-6 mb-6">
                <h2 class="text-lg font-semibold text-gray-800 mb-4 border-b pb-2">
                    <i class="fas fa-user-plus mr-2 text-orange-500"></i>
                    Santri Belum Terabsen
                    <span class="text-sm font-normal text-gray-500">(<?php echo e($santriTambahan->count()); ?> santri)</span>
                </h2>
                <?php $__currentLoopData = $santriTambahan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $st): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="flex flex-col md:flex-row md:items-center gap-3 py-3 border-b last:border-0">
                        <div class="w-8 h-8 bg-orange-400 rounded-full flex items-center justify-center flex-shrink-0">
                            <span class="text-white text-xs font-bold">
                                <?php echo e(strtoupper(substr($st->santri->nama_lengkap, 0, 1))); ?>

                            </span>
                        </div>
                        <div class="flex-1">
                            <p class="font-medium text-sm text-gray-800"><?php echo e($st->santri->nama_lengkap); ?></p>
                            <p class="text-xs text-gray-400">NIS: <?php echo e($st->santri->nis); ?></p>
                        </div>
                        <input type="hidden" name="tambahan[<?php echo e($loop->index); ?>][santri_tingkat_id]"
                            value="<?php echo e($st->id); ?>">
                        <div class="flex gap-3 flex-wrap">
                            <?php $__currentLoopData = ['hadir' => 'green', 'sakit' => 'blue', 'izin' => 'yellow', 'alpha' => 'red']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val => $color): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <label class="flex items-center gap-1 text-xs cursor-pointer">
                                    <input type="radio" name="tambahan[<?php echo e($loop->parent->index); ?>][status]"
                                        value="<?php echo e($val); ?>" <?php echo e($val == 'alpha' ? 'checked' : ''); ?>>
                                    <span
                                        class="text-<?php echo e($color); ?>-700 font-medium capitalize"><?php echo e(ucfirst($val)); ?></span>
                                </label>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                        <div class="md:w-48">
                            <input type="text" name="tambahan[<?php echo e($loop->index); ?>][keterangan]"
                                class="w-full border rounded px-2 py-1 text-xs text-gray-600" placeholder="Keterangan...">
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        <?php endif; ?>

        <div class="flex gap-3">
            <button type="submit"
                class="bg-[#1e3a5f] text-white px-8 py-2 rounded-lg hover:bg-[#2a4a7a] transition font-semibold">
                <i class="fas fa-save mr-2"></i> Simpan Perubahan
            </button>
            <a href="<?php echo e(route('guru.absensi.rekap', ['jadwal_id' => $absensiGuru->jadwal_mengajar_id])); ?>"
                class="bg-gray-200 text-gray-700 px-6 py-2 rounded-lg hover:bg-gray-300 transition">
                Batal
            </a>
        </div>
    </form>

    <script>
        function tandaiSemua(status) {
            document.querySelectorAll('.santri-status').forEach(radio => {
                if (radio.value === status) radio.checked = true;
            });
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/qiyor/Documents/PBL/project/pesantren_app/resources/views/guru/absensi/edit-santri.blade.php ENDPATH**/ ?>