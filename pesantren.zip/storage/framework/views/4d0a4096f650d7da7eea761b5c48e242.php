<?php $__env->startSection('title', 'Halaman Statis'); ?>
<?php $__env->startSection('content'); ?>

    <div class="flex justify-between items-center mb-6">
        <div>
            <h1 class="text-2xl font-bold text-gray-800">Halaman Statis</h1>
            <p class="text-sm text-gray-500 mt-1">Profil, fasilitas, kontak, dan halaman lainnya</p>
        </div>
        <a href="<?php echo e(route('admin.posts.create', ['type' => 'page'])); ?>"
            class="bg-[#1e3a5f] text-white px-4 py-2 rounded-lg hover:bg-[#2a4a7a] transition">
            <i class="fas fa-plus mr-2"></i> Tambah Halaman
        </a>
    </div>

    <?php if(session('success')): ?>
        <div class="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded mb-4"><?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>

    
    <div class="mb-6 flex gap-3">
        <div class="flex-1">
            <?php if (isset($component)) { $__componentOriginal4c1005aa12a1806956b715b534f8b19a = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal4c1005aa12a1806956b715b534f8b19a = $attributes; } ?>
<?php $component = App\View\Components\SearchBar::resolve(['placeholder' => 'Cari judul halaman...'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('search-bar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\SearchBar::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal4c1005aa12a1806956b715b534f8b19a)): ?>
<?php $attributes = $__attributesOriginal4c1005aa12a1806956b715b534f8b19a; ?>
<?php unset($__attributesOriginal4c1005aa12a1806956b715b534f8b19a); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4c1005aa12a1806956b715b534f8b19a)): ?>
<?php $component = $__componentOriginal4c1005aa12a1806956b715b534f8b19a; ?>
<?php unset($__componentOriginal4c1005aa12a1806956b715b534f8b19a); ?>
<?php endif; ?>
        </div>
        <select onchange="window.location.href=updateQueryParam('status', this.value)"
            class="border rounded-lg px-3 py-2 text-sm">
            <option value="">Semua Status</option>
            <option value="published" <?php echo e(request('status') == 'published' ? 'selected' : ''); ?>>Published</option>
            <option value="draft" <?php echo e(request('status') == 'draft' ? 'selected' : ''); ?>>Draft</option>
        </select>
    </div>

    <div class="bg-white rounded-xl shadow-md overflow-hidden">
        <table class="w-full">
            <thead class="bg-gray-50 border-b">
                <tr>
                    <th class="px-6 py-3 text-left text-sm font-semibold text-gray-600">Judul</th>
                    <th class="px-6 py-3 text-left text-sm font-semibold text-gray-600">Slug</th>
                    <th class="px-6 py-3 text-left text-sm font-semibold text-gray-600">Urutan</th>
                    <th class="px-6 py-3 text-left text-sm font-semibold text-gray-600">Status</th>
                    <th class="px-6 py-3 text-left text-sm font-semibold text-gray-600">Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr class="border-b hover:bg-gray-50">
                        <td class="px-6 py-3 font-medium text-sm"><?php echo e($post->title); ?></td>
                        <td class="px-6 py-3 text-sm text-gray-500">
                            <a href="<?php echo e(url('/page/' . $post->slug)); ?>" target="_blank"
                                class="text-blue-600 hover:underline">
                                /page/<?php echo e($post->slug); ?>

                            </a>
                        </td>
                        <td class="px-6 py-3 text-sm text-gray-500"><?php echo e($post->menu_order); ?></td>
                        <td class="px-6 py-3">
                            <?php if($post->published_at): ?>
                                <span
                                    class="text-xs bg-green-100 text-green-700 px-2 py-1 rounded-full font-semibold">Published</span>
                            <?php else: ?>
                                <span
                                    class="text-xs bg-yellow-100 text-yellow-700 px-2 py-1 rounded-full font-semibold">Draft</span>
                            <?php endif; ?>
                        </td>
                        <td class="px-6 py-3">
                            <div class="flex gap-2">
                                <a href="<?php echo e(route('admin.posts.edit', $post->id)); ?>"
                                    class="text-yellow-600 hover:text-yellow-800 text-sm">
                                    <i class="fas fa-edit mr-1"></i> Edit
                                </a>
                                <form action="<?php echo e(route('admin.posts.destroy', $post->id)); ?>" method="POST" class="inline">
                                    <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="text-red-600 hover:text-red-800 text-sm"
                                        onclick="return confirm('Yakin hapus halaman ini?')">
                                        <i class="fas fa-trash mr-1"></i> Hapus
                                    </button>
                                </form>
                            </div>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="5" class="px-6 py-8 text-center text-gray-500">Belum ada halaman statis.</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
        <?php if($posts->hasPages()): ?>
            <div class="px-6 py-4 border-t bg-gray-50"><?php echo e($posts->links()); ?></div>
        <?php endif; ?>
    </div>

    <script>
        function updateQueryParam(key, value) {
            const url = new URL(window.location.href);
            if (value) url.searchParams.set(key, value);
            else url.searchParams.delete(key);
            url.searchParams.delete('page');
            return url.toString();
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/qiyor/Documents/PBL/project/pesantren_app/resources/views/admin/posts/pages.blade.php ENDPATH**/ ?>