<?php $__env->startSection('title', $type == 'page' ? 'Tambah Halaman' : 'Tambah Artikel'); ?>
<?php $__env->startSection('content'); ?>

    <div class="mb-6">
        <h1 class="text-2xl font-bold text-gray-800">
            <?php echo e($type == 'page' ? 'Tambah Halaman Statis' : 'Tambah Artikel'); ?>

        </h1>
        <p class="text-gray-500">Menambahkan konten baru</p>
    </div>

    <div class="bg-white rounded-lg shadow p-6">
        <form method="POST" action="<?php echo e(route('admin.posts.store')); ?>" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>

            
            <input type="hidden" name="post_type" value="<?php echo e($type); ?>">

            <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                    <label class="block text-gray-700 font-medium mb-2">Judul <span class="text-red-500">*</span></label>
                    <input type="text" name="title" value="<?php echo e(old('title')); ?>" required
                        class="w-full border border-gray-300 rounded-lg px-4 py-2">
                    <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="text-red-500 text-xs mt-1"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <?php if($type == 'post'): ?>
                    <div>
                        <label class="block text-gray-700 font-medium mb-2">Kategori</label>
                        <select name="post_category_id" class="w-full border border-gray-300 rounded-lg px-4 py-2">
                            <option value="">Pilih Kategori</option>
                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($cat->id); ?>"
                                    <?php echo e(old('post_category_id') == $cat->id ? 'selected' : ''); ?>>
                                    <?php echo e($cat->name); ?>

                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                <?php endif; ?>

                <?php if($type == 'page'): ?>
                    <div>
                        <label class="block text-gray-700 font-medium mb-2">Urutan Menu</label>
                        <input type="number" name="menu_order" value="<?php echo e(old('menu_order', 0)); ?>"
                            class="w-full border border-gray-300 rounded-lg px-4 py-2">
                        <p class="text-xs text-gray-400 mt-1">Angka kecil tampil lebih dulu</p>
                    </div>
                <?php endif; ?>

                <div>
                    <label class="block text-gray-700 font-medium mb-2">Gambar Unggulan</label>
                    <input type="file" name="featured_image" accept="image/*"
                        class="w-full border border-gray-300 rounded-lg px-4 py-2" id="imageInput"
                        onchange="previewImage(this)">
                    <div id="imagePreview" class="mt-2 hidden">
                        <img id="previewImg" src="" class="w-32 h-32 object-cover rounded">
                        <button type="button" onclick="removeImagePreview()"
                            class="mt-1 text-xs text-red-500 hover:text-red-700">
                            <i class="fas fa-times mr-1"></i> Hapus pilihan
                        </button>
                    </div>
                </div>

                <div>
                    <label class="block text-gray-700 font-medium mb-2">Tanggal Publikasi</label>
                    <input type="datetime-local" name="published_at"
                        value="<?php echo e(old('published_at', now()->format('Y-m-d\TH:i'))); ?>"
                        class="w-full border border-gray-300 rounded-lg px-4 py-2">
                    <p class="text-xs text-gray-400 mt-1">Kosongkan untuk simpan sebagai draft</p>
                </div>
            </div>

            <div class="mt-4">
                <label class="block text-gray-700 font-medium mb-2">Konten</label>
                <textarea name="content" id="content" rows="15" class="w-full border border-gray-300 rounded-lg px-4 py-2"><?php echo e(old('content')); ?></textarea>
            </div>

            <div class="flex gap-3 mt-6">
                <button type="submit" class="bg-[#1e3a5f] text-white px-6 py-2 rounded-lg hover:bg-[#2a4a7a] transition">
                    <i class="fas fa-save mr-2"></i> Simpan
                </button>
                <a href="<?php echo e($type == 'page' ? route('admin.posts.pages') : route('admin.posts.index')); ?>"
                    class="bg-gray-200 text-gray-700 px-6 py-2 rounded-lg hover:bg-gray-300 transition">
                    Batal
                </a>
            </div>
        </form>
    </div>

    <link href="https://cdn.jsdelivr.net/npm/summernote@0.8.18/dist/summernote-lite.min.css" rel="stylesheet">
    <script src="https://code.jquery.com/jquery-3.4.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/summernote@0.8.18/dist/summernote-lite.min.js"></script>
    <script>
        $(document).ready(function() {
            $('#content').summernote({
                height: 500,
                toolbar: [
                    ['style', ['style']],
                    ['font', ['bold', 'underline', 'clear']],
                    ['color', ['color']],
                    ['para', ['ul', 'ol', 'paragraph']],
                    ['table', ['table']],
                    ['insert', ['link', 'picture']],
                    ['view', ['fullscreen', 'codeview']]
                ]
            });
        });

        function previewImage(input) {
            if (input.files && input.files[0]) {
                const reader = new FileReader();
                reader.onload = e => {
                    document.getElementById('previewImg').src = e.target.result;
                    document.getElementById('imagePreview').classList.remove('hidden');
                };
                reader.readAsDataURL(input.files[0]);
            }
        }

        function removeImagePreview() {
            document.getElementById('imageInput').value = '';
            document.getElementById('imagePreview').classList.add('hidden');
            document.getElementById('previewImg').src = '';
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/qiyor/Documents/PBL/project/pesantren_app/resources/views/admin/posts/create.blade.php ENDPATH**/ ?>