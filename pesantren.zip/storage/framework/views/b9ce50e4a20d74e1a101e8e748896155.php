<?php $__env->startSection('title', 'Isi Absensi'); ?>
<?php $__env->startSection('content'); ?>

<div class="mb-6 flex items-center gap-3">
    <a href="<?php echo e(route('guru.absensi.index')); ?>" class="text-gray-500 hover:text-[#1e3a5f]">
        <i class="fas fa-arrow-left"></i> Kembali
    </a>
    <div>
        <h1 class="text-2xl font-bold text-gray-800">Isi Absensi</h1>
        <p class="text-gray-500 text-sm">
            <?php echo e($jadwal->kurikulum->mataPelajaran->nama_mapel); ?> -
            <?php echo e($jadwal->kurikulum->tingkatDiniyah->nama_tingkat); ?> |
            Pertemuan ke-<?php echo e($pertemuanKe); ?>

        </p>
    </div>
</div>

<?php if($absensiHariIni): ?>
    <div class="bg-yellow-50 border border-yellow-300 text-yellow-800 px-4 py-3 rounded mb-6">
        <i class="fas fa-exclamation-triangle mr-2"></i>
        Anda sudah mengisi absensi untuk jadwal ini hari ini.
        Status: <strong><?php echo e(ucfirst($absensiHariIni->status)); ?></strong>
    </div>
<?php endif; ?>

<form method="POST" action="<?php echo e(route('guru.absensi.store', $jadwal->id)); ?>">
    <?php echo csrf_field(); ?>

    
    <div class="bg-white rounded-xl shadow-sm p-6 mb-6">
        <h2 class="text-lg font-semibold text-gray-800 mb-4 border-b pb-2">
            <i class="fas fa-user-check mr-2 text-[#1e3a5f]"></i> Kehadiran Saya
        </h2>
        <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
                <label class="block text-sm font-medium text-gray-700 mb-1">Tanggal</label>
                <input type="date" name="tanggal" value="<?php echo e(today()->format('Y-m-d')); ?>"
                    class="w-full border rounded-lg px-4 py-2 text-sm" required>
                <?php $__errorArgs = ['tanggal'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-red-500 text-xs mt-1"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div>
                <label class="block text-sm font-medium text-gray-700 mb-1">Status Kehadiran</label>
                <div class="grid grid-cols-2 gap-2">
                    <?php $__currentLoopData = ['hadir' => ['green', 'check-circle'], 'sakit' => ['blue', 'procedures'], 'izin' => ['yellow', 'clipboard'], 'alpha' => ['red', 'times-circle']]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val => $conf): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <label class="flex items-center gap-2 border rounded-lg px-3 py-2 cursor-pointer hover:bg-gray-50
                        <?php echo e($val == 'hadir' ? 'border-green-300' : ($val == 'sakit' ? 'border-blue-300' : ($val == 'izin' ? 'border-yellow-300' : 'border-red-300'))); ?>">
                        <input type="radio" name="status" value="<?php echo e($val); ?>"
                            <?php echo e($val == 'hadir' ? 'checked' : ''); ?>

                            class="accent-<?php echo e($conf[0]); ?>-600"
                            onchange="toggleAbsensiSantri(this.value)">
                        <span class="text-sm capitalize text-<?php echo e($conf[0]); ?>-700 font-medium">
                            <i class="fas fa-<?php echo e($conf[1]); ?> mr-1"></i> <?php echo e(ucfirst($val)); ?>

                        </span>
                    </label>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <?php $__errorArgs = ['status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-red-500 text-xs mt-1"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="md:col-span-2">
                <label class="block text-sm font-medium text-gray-700 mb-1">Keterangan (Opsional)</label>
                <input type="text" name="keterangan" value="<?php echo e(old('keterangan')); ?>"
                    class="w-full border rounded-lg px-4 py-2 text-sm"
                    placeholder="Contoh: Izin keperluan keluarga">
            </div>
        </div>
    </div>

    
    <div id="absensi-santri-section" class="bg-white rounded-xl shadow-sm p-6 mb-6">
        <div class="flex justify-between items-center mb-4 border-b pb-2">
            <h2 class="text-lg font-semibold text-gray-800">
                <i class="fas fa-users mr-2 text-[#1e3a5f]"></i>
                Absensi Santri
                <span class="text-sm font-normal text-gray-500">(<?php echo e($santriList->count()); ?> santri)</span>
            </h2>
            
            <div class="flex gap-2">
                <button type="button" onclick="tandaiSemua('hadir')"
                    class="text-xs bg-green-100 text-green-700 px-3 py-1 rounded-full hover:bg-green-200">
                    Semua Hadir
                </button>
                <button type="button" onclick="tandaiSemua('alpha')"
                    class="text-xs bg-red-100 text-red-700 px-3 py-1 rounded-full hover:bg-red-200">
                    Semua Alpha
                </button>
            </div>
        </div>

        <?php $__empty_1 = true; $__currentLoopData = $santriList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $st): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <div class="flex flex-col md:flex-row md:items-center gap-3 py-3 border-b last:border-0">
            <div class="w-8 h-8 bg-[#1e3a5f] rounded-full flex items-center justify-center flex-shrink-0">
                <span class="text-white text-xs font-bold"><?php echo e(strtoupper(substr($st->santri->nama_lengkap, 0, 1))); ?></span>
            </div>
            <div class="flex-1">
                <p class="font-medium text-sm text-gray-800"><?php echo e($st->santri->nama_lengkap); ?></p>
                <p class="text-xs text-gray-400">NIS: <?php echo e($st->santri->nis); ?></p>
            </div>
            <div class="flex gap-2 flex-wrap">
                <?php $__currentLoopData = ['hadir' => 'green', 'sakit' => 'blue', 'izin' => 'yellow', 'alpha' => 'red']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val => $color): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <label class="flex items-center gap-1 text-xs cursor-pointer">
                    <input type="radio" name="absensi[<?php echo e($st->id); ?>][status]"
                        value="<?php echo e($val); ?>"
                        class="santri-status accent-<?php echo e($color); ?>-600"
                        <?php echo e($val == 'hadir' ? 'checked' : ''); ?>>
                    <span class="text-<?php echo e($color); ?>-700 font-medium capitalize"><?php echo e(ucfirst($val)); ?></span>
                </label>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <div class="md:w-48">
                <input type="text" name="absensi[<?php echo e($st->id); ?>][keterangan]"
                    class="w-full border rounded px-2 py-1 text-xs text-gray-600"
                    placeholder="Keterangan...">
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <p class="text-center text-gray-400 py-6">Belum ada santri di tingkat ini.</p>
        <?php endif; ?>
    </div>

    <?php if(!$absensiHariIni): ?>
    <div class="flex gap-3">
        <button type="submit"
            class="bg-[#1e3a5f] text-white px-8 py-2 rounded-lg hover:bg-[#2a4a7a] transition font-semibold">
            <i class="fas fa-save mr-2"></i> Simpan Absensi
        </button>
        <a href="<?php echo e(route('guru.absensi.index')); ?>"
            class="bg-gray-200 text-gray-700 px-6 py-2 rounded-lg hover:bg-gray-300 transition">
            Batal
        </a>
    </div>
    <?php endif; ?>
</form>

<script>
function toggleAbsensiSantri(status) {
    const section = document.getElementById('absensi-santri-section');
    if (status === 'hadir') {
        section.style.opacity = '1';
        section.querySelectorAll('input').forEach(i => i.disabled = false);
    } else {
        section.style.opacity = '0.5';
        section.querySelectorAll('input').forEach(i => i.disabled = true);
    }
}

function tandaiSemua(status) {
    document.querySelectorAll('.santri-status').forEach(radio => {
        if (radio.value === status) radio.checked = true;
    });
}
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/qiyor/Documents/PBL/project/pesantren_app/resources/views/guru/absensi/create.blade.php ENDPATH**/ ?>