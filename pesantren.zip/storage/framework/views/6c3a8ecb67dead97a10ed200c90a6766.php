<?php $__env->startSection('title', 'Materi Pembelajaran'); ?>
<?php $__env->startSection('content'); ?>

<div class="mb-6">
    <h1 class="text-2xl font-bold text-gray-800">Materi Pembelajaran</h1>
    <p class="text-gray-500 text-sm mt-1">Upload dan kelola materi untuk santri</p>
</div>

<?php if(session('success')): ?>
    <div class="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded mb-4"><?php echo e(session('success')); ?></div>
<?php endif; ?>
<?php if(session('error')): ?>
    <div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-4"><?php echo e(session('error')); ?></div>
<?php endif; ?>

<div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
    
    <div class="bg-white rounded-xl shadow-sm p-6">
        <h2 class="text-lg font-semibold mb-4 border-b pb-2">Upload Materi</h2>
        <form method="POST" action="<?php echo e(route('guru.materi.store')); ?>" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div class="space-y-3">
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1">Judul Materi</label>
                    <input type="text" name="judul" value="<?php echo e(old('judul')); ?>"
                        class="w-full border rounded-lg px-3 py-2 text-sm" required>
                    <?php $__errorArgs = ['judul'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-red-500 text-xs mt-1"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1">Mata Pelajaran</label>
                    <select name="mapel_id" class="w-full border rounded-lg px-3 py-2 text-sm">
                        <option value="">Pilih Mapel</option>
                        <?php $__currentLoopData = $mapelList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($m->id); ?>"><?php echo e($m->nama_mapel); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1">Tingkat</label>
                    <select name="tingkat_id" class="w-full border rounded-lg px-3 py-2 text-sm">
                        <option value="">Pilih Tingkat</option>
                        <?php $__currentLoopData = $tingkatList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($t->id); ?>"><?php echo e($t->nama_tingkat); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1">Deskripsi</label>
                    <textarea name="deskripsi" rows="2"
                        class="w-full border rounded-lg px-3 py-2 text-sm"><?php echo e(old('deskripsi')); ?></textarea>
                </div>
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1">File</label>
                    <input type="file" name="file"
                        class="w-full border rounded-lg px-3 py-2 text-sm"
                        accept=".pdf,.doc,.docx,.ppt,.pptx,.xls,.xlsx,.jpg,.jpeg,.png,.mp4">
                    <p class="text-xs text-gray-400 mt-1">Maks 10MB. Format: pdf, doc, ppt, xls, jpg, png, mp4</p>
                    <?php $__errorArgs = ['file'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-red-500 text-xs mt-1"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <button type="submit"
                    class="w-full bg-[#1e3a5f] text-white py-2 rounded-lg hover:bg-[#2a4a7a] transition text-sm">
                    <i class="fas fa-upload mr-1"></i> Upload
                </button>
            </div>
        </form>
    </div>

    
    <div class="lg:col-span-2 space-y-3">
        <?php $__empty_1 = true; $__currentLoopData = $materi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <div class="bg-white rounded-xl shadow-sm p-4 flex items-start justify-between gap-4">
            <div class="flex items-start gap-3">
                <div class="w-10 h-10 bg-[#1e3a5f] rounded-lg flex items-center justify-center flex-shrink-0">
                    <?php
                        $ext = pathinfo($m->path_file, PATHINFO_EXTENSION);
                        $icon = match($ext) {
                            'pdf'           => 'fa-file-pdf',
                            'doc', 'docx'   => 'fa-file-word',
                            'ppt', 'pptx'   => 'fa-file-powerpoint',
                            'xls', 'xlsx'   => 'fa-file-excel',
                            'jpg','jpeg','png' => 'fa-file-image',
                            'mp4'           => 'fa-file-video',
                            default         => 'fa-file',
                        };
                    ?>
                    <i class="fas <?php echo e($icon); ?> text-white text-sm"></i>
                </div>
                <div>
                    <p class="font-semibold text-sm text-gray-800"><?php echo e($m->judul); ?></p>
                    <p class="text-xs text-gray-400 mt-0.5">
                        <?php echo e($m->mataPelajaran->nama_mapel ?? '-'); ?> |
                        <?php echo e($m->tingkat->nama_tingkat ?? '-'); ?> |
                        <?php echo e($m->diunduh); ?> diunduh |
                        <?php echo e(number_format($m->ukuran_file / 1024, 0)); ?> KB
                    </p>
                    <?php if($m->deskripsi): ?>
                        <p class="text-xs text-gray-500 mt-1"><?php echo e($m->deskripsi); ?></p>
                    <?php endif; ?>
                    <p class="text-xs text-gray-400 mt-1"><?php echo e($m->created_at->format('d M Y H:i')); ?></p>
                </div>
            </div>
            <form action="<?php echo e(route('guru.materi.destroy', $m->id)); ?>" method="POST" class="flex-shrink-0">
                <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                <button type="submit" class="text-red-500 hover:text-red-700 text-sm"
                    onclick="return confirm('Yakin hapus materi ini?')">
                    <i class="fas fa-trash"></i>
                </button>
            </form>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <div class="bg-white rounded-xl shadow-sm p-10 text-center">
            <i class="fas fa-folder-open text-4xl text-gray-300 mb-3"></i>
            <p class="text-gray-500">Belum ada materi yang diupload.</p>
        </div>
        <?php endif; ?>

        <?php if($materi->hasPages()): ?>
            <div class="mt-4"><?php echo e($materi->links()); ?></div>
        <?php endif; ?>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/qiyor/Documents/PBL/project/pesantren_app/resources/views/guru/materi/index.blade.php ENDPATH**/ ?>